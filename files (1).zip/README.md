# Tour Operator Portal

A centralized digital ecosystem for managing all aspects of a tour operator business—supporting internal teams (operations, finance, HR, marketing) and external stakeholders (clients, agents, vendors, service providers).

## Features

- **Dashboard** with role-based widgets, analytics, notifications, and navigation.
- **Tour Package Management**: CRUD for quotations, pricing, itineraries, media uploads.
- **Booking Engine**: Real-time booking, calendar sync, payment gateways.
- **Role-Based Access Control (RBAC)**: Manage users, roles, permissions.
- **Reporting & Analytics**: Department dashboards, exportable reports, charts.
- **HR Module**: Staff directory, leave, performance, payroll.
- **Finance Module**: Invoice, expenses, payment tracking.
- **Marketing/Sales**: Campaigns, lead tracking, referral analytics.
- **Communication**: In-app messaging, notifications.
- **Extensible** to localization, CRM, and online sales.

## Tech Stack

- **Backend**: FastAPI (Python), SQLAlchemy ORM
- **Frontend**: Jinja2 templates (can be replaced with React/Angular)
- **Database**: SQLite (default), can be PostgreSQL/MySQL
- **Auth**: JWT (token-based, extendable to OAuth2)
- **Charts**: Chart.js (in templates)
- **Deployment**: Docker, Gunicorn/Uvicorn, Nginx, cloud hosting (AWS/Azure/GCP)

## Setup

1. **Clone the repo**
    ```bash
    git clone https://github.com/<your-org>/<your-repo>.git
    cd <your-repo>
    ```

2. **Create a virtualenv & install dependencies**
    ```bash
    python3 -m venv venv
    source venv/bin/activate
    pip install -r requirements.txt
    ```

3. **Initialize the database**
    ```bash
    python
    >>> from app.models import Base, engine
    >>> Base.metadata.create_all(bind=engine)
    ```

4. **Run the server**
    ```bash
    uvicorn app.main:app --reload
    ```
    - Visit [http://localhost:8000/dashboard](http://localhost:8000/dashboard)

## Deployment (Docker Example)

1. **Dockerfile**
    ```dockerfile
    FROM python:3.10
    WORKDIR /app
    COPY . .
    RUN pip install -r requirements.txt
    CMD ["uvicorn", "app.main:app", "--host", "0.0.0.0", "--port", "8000"]
    ```

2. **Build & Run**
    ```bash
    docker build -t tour-portal .
    docker run -d -p 8000:8000 tour-portal
    ```

3. **Production**
    - Use Gunicorn/Uvicorn behind Nginx for load balancing.
    - Set up environment variables for DB, secret keys.
    - Use PostgreSQL/MySQL for production DB.
    - Configure backups, monitoring (New Relic, Datadog), SSL/TLS.

## Environment Variables

- `DATABASE_URL` (default: sqlite:///./portal.db)
- `SECRET_KEY` (for JWT)
- `EMAIL/TWILIO/STRIPE` keys (if integrating)

## Extending

- Connect to real CRM, payment, calendar, OTA APIs.
- Replace templates with React/Angular SPA and call REST endpoints.
- Add WebSocket endpoints for real-time notifications.

## Directory Structure

```
app/
├── main.py
├── models.py
├── deps.py
├── auth.py
├── api/
│   └── v1/
│       ├── dashboard.py
│       ├── tours.py
│       ├── bookings.py
│       ├── rbac.py
│       ├── reporting.py
│       ├── hr.py
│       ├── finance.py
│       ├── marketing.py
│       ├── comms.py
├── templates/
│   ├── dashboard.html
│   ├── tours.html
│   └── ...
```

## License

MIT

## Contact

For support or demo access, contact [Your Team](mailto:hello@yourdomain.com).
