from app.api.v1 import auth_graph
app.include_router(auth_graph.router, prefix="/auth")