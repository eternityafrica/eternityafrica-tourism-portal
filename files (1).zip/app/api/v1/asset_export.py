from fastapi import APIRouter, Depends
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session
from app.models import Asset
from app.deps import get_db
from app.utils.depreciation import straight_line_depreciation, declining_balance_depreciation
import io
import csv

router = APIRouter()

@router.get("/export", response_class=StreamingResponse)
async def export_assets_csv(db: Session = Depends(get_db)):
    assets = db.query(Asset).all()
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow([
        "Name", "Type", "Location", "Assigned To", "Status",
        "Purchase Date", "Purchase Value", "Current Value", "Depreciation Method", "Useful Life (years)"
    ])
    for a in assets:
        current_value = (
            straight_line_depreciation(a.purchase_value, a.useful_life_years, a.purchase_date)
            if a.depreciation_method == "Straight-Line"
            else declining_balance_depreciation(a.purchase_value, a.useful_life_years, a.purchase_date)
        )
        writer.writerow([
            a.name, a.type, a.location, a.assigned_to, a.status,
            a.purchase_date.strftime('%Y-%m-%d'), "%.2f" % a.purchase_value,
            "%.2f" % current_value, a.depreciation_method, a.useful_life_years
        ])
    output.seek(0)
    headers = {"Content-Disposition": "attachment; filename=assets.csv"}
    return StreamingResponse(output, media_type="text/csv", headers=headers)