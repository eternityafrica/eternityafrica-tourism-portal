from fastapi import APIRouter, Request, UploadFile, File, Depends
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy.orm import Session
from app.models import InventoryItem
from app.deps import get_db
import csv
import io

router = APIRouter()

@router.get("/bulk_import", response_class=HTMLResponse)
async def bulk_import_form(request: Request):
    return request.app.templates.TemplateResponse("inventory_bulk_import.html", {"request": request})

@router.post("/bulk_import", response_class=RedirectResponse)
async def bulk_import_inventory(file: UploadFile = File(...), db: Session = Depends(get_db)):
    contents = await file.read()
    reader = csv.DictReader(io.StringIO(contents.decode()))
    for row in reader:
        item = InventoryItem(
            name=row["Name"],
            category=row["Category"],
            description=row.get("Description", ""),
            quantity=int(row["Quantity"]),
            unit=row["Unit"],
            location=row.get("Location", ""),
            reorder_point=int(row.get("Reorder Point", 0))
        )
        db.add(item)
    db.commit()
    return RedirectResponse("/inventory", status_code=303)