from fastapi import APIRouter, Request, Form, Depends, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from app.models import Vendor, InventoryItem
from app.deps import get_db
from app.auth import get_current_user

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")

# Vendor endpoints
@router.get("/vendors", response_class=HTMLResponse)
async def vendor_list(request: Request, db: Session = Depends(get_db), user=Depends(get_current_user)):
    vendors = db.query(Vendor).all()
    return templates.TemplateResponse("vendors.html", {"request": request, "vendors": vendors, "user": user})

@router.get("/vendors/new", response_class=HTMLResponse)
async def create_vendor_form(request: Request, user=Depends(get_current_user)):
    return templates.TemplateResponse("vendor_create.html", {"request": request, "user": user})

@router.post("/vendors/new", response_class=RedirectResponse)
async def create_vendor(
    name: str = Form(...),
    type: str = Form(...),
    contact: str = Form(...),
    description: str = Form(...),
    is_active: bool = Form(...),
    db: Session = Depends(get_db),
    user=Depends(get_current_user)
):
    v = Vendor(name=name, type=type, contact=contact, description=description, is_active=is_active)
    db.add(v)
    db.commit()
    return RedirectResponse("/operations/vendors", status_code=303)

@router.get("/vendors/edit/{vid}", response_class=HTMLResponse)
async def edit_vendor(request: Request, vid: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    v = db.query(Vendor).filter(Vendor.id == vid).first()
    if not v:
        raise HTTPException(status_code=404, detail="Vendor not found")
    return templates.TemplateResponse("vendor_edit.html", {"request": request, "vendor": v, "user": user})

@router.post("/vendors/edit/{vid}", response_class=RedirectResponse)
async def update_vendor(
    vid: int,
    name: str = Form(...),
    type: str = Form(...),
    contact: str = Form(...),
    description: str = Form(...),
    is_active: bool = Form(...),
    db: Session = Depends(get_db),
    user=Depends(get_current_user)
):
    v = db.query(Vendor).filter(Vendor.id == vid).first()
    if not v:
        raise HTTPException(status_code=404, detail="Vendor not found")
    v.name = name
    v.type = type
    v.contact = contact
    v.description = description
    v.is_active = is_active
    db.commit()
    return RedirectResponse("/operations/vendors", status_code=303)

@router.get("/vendors/delete/{vid}", response_class=RedirectResponse)
async def delete_vendor(vid: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    v = db.query(Vendor).filter(Vendor.id == vid).first()
    if v:
        db.delete(v)
        db.commit()
    return RedirectResponse("/operations/vendors", status_code=303)

# Inventory endpoints
@router.get("/inventory", response_class=HTMLResponse)
async def inventory_list(request: Request, db: Session = Depends(get_db), user=Depends(get_current_user)):
    inventory = db.query(InventoryItem).all()
    return templates.TemplateResponse("inventory.html", {"request": request, "inventory": inventory, "user": user})

@router.get("/inventory/new", response_class=HTMLResponse)
async def create_inventory_form(request: Request, user=Depends(get_current_user)):
    return templates.TemplateResponse("inventory_create.html", {"request": request, "user": user})

@router.post("/inventory/new", response_class=RedirectResponse)
async def create_inventory(
    item_type: str = Form(...),
    name: str = Form(...),
    status: str = Form(...),
    location: str = Form(...),
    db: Session = Depends(get_db),
    user=Depends(get_current_user)
):
    i = InventoryItem(item_type=item_type, name=name, status=status, location=location)
    db.add(i)
    db.commit()
    return RedirectResponse("/operations/inventory", status_code=303)

@router.get("/inventory/edit/{iid}", response_class=HTMLResponse)
async def edit_inventory(request: Request, iid: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    i = db.query(InventoryItem).filter(InventoryItem.id == iid).first()
    if not i:
        raise HTTPException(status_code=404, detail="Inventory item not found")
    return templates.TemplateResponse("inventory_edit.html", {"request": request, "item": i, "user": user})

@router.post("/inventory/edit/{iid}", response_class=RedirectResponse)
async def update_inventory(
    iid: int,
    item_type: str = Form(...),
    name: str = Form(...),
    status: str = Form(...),
    location: str = Form(...),
    db: Session = Depends(get_db),
    user=Depends(get_current_user)
):
    i = db.query(InventoryItem).filter(InventoryItem.id == iid).first()
    if not i:
        raise HTTPException(status_code=404, detail="Inventory item not found")
    i.item_type = item_type
    i.name = name
    i.status = status
    i.location = location
    db.commit()
    return RedirectResponse("/operations/inventory", status_code=303)

@router.get("/inventory/delete/{iid}", response_class=RedirectResponse)
async def delete_inventory(iid: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    i = db.query(InventoryItem).filter(InventoryItem.id == iid).first()
    if i:
        db.delete(i)
        db.commit()
    return RedirectResponse("/operations/inventory", status_code=303)