from fastapi import APIRouter, Request, Depends
from sqlalchemy.orm import Session
from app.models import Affiliate, Referral
from app.deps import get_db

router = APIRouter()

@router.get("/analytics", response_class=HTMLResponse)
async def affiliate_analytics(request: Request, db: Session = Depends(get_db)):
    # Example: referrals by month
    import collections
    monthly_stats = collections.defaultdict(lambda: {"total":0, "confirmed":0, "paid":0})
    referrals = db.query(Referral).all()
    for r in referrals:
        month = r.created_at.strftime("%Y-%m")
        monthly_stats[month]["total"] += 1
        if r.status == "Confirmed":
            monthly_stats[month]["confirmed"] += 1
        if r.status == "Paid":
            monthly_stats[month]["paid"] += 1
    sorted_stats = sorted(monthly_stats.items())
    return request.app.templates.TemplateResponse("affiliate_analytics.html", {"request": request, "monthly_stats": sorted_stats})