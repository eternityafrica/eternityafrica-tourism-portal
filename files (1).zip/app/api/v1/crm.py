from fastapi import APIRouter, Request, Form, Depends, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from app.models import CRMClient
from app.deps import get_db
from app.auth import get_current_user

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")

@router.get("/", response_class=HTMLResponse)
async def crm_list(request: Request, db: Session = Depends(get_db), user=Depends(get_current_user)):
    clients = db.query(CRMClient).all()
    return templates.TemplateResponse("crm.html", {"request": request, "clients": clients, "user": user})

@router.get("/new", response_class=HTMLResponse)
async def create_client_form(request: Request, user=Depends(get_current_user)):
    return templates.TemplateResponse("crm_create.html", {"request": request, "user": user})

@router.post("/new", response_class=RedirectResponse)
async def create_client(
    name: str = Form(...),
    email: str = Form(...),
    booking_history: str = Form(...),
    preferences: str = Form(...),
    feedback: str = Form(...),
    db: Session = Depends(get_db),
    user=Depends(get_current_user)
):
    c = CRMClient(name=name, email=email, booking_history=booking_history, preferences=preferences, feedback=feedback)
    db.add(c)
    db.commit()
    return RedirectResponse("/crm", status_code=303)

@router.get("/edit/{cid}", response_class=HTMLResponse)
async def edit_client(request: Request, cid: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    c = db.query(CRMClient).filter(CRMClient.id == cid).first()
    if not c:
        raise HTTPException(status_code=404, detail="Client not found")
    return templates.TemplateResponse("crm_edit.html", {"request": request, "client": c, "user": user})

@router.post("/edit/{cid}", response_class=RedirectResponse)
async def update_client(
    cid: int,
    name: str = Form(...),
    email: str = Form(...),
    booking_history: str = Form(...),
    preferences: str = Form(...),
    feedback: str = Form(...),
    db: Session = Depends(get_db),
    user=Depends(get_current_user)
):
    c = db.query(CRMClient).filter(CRMClient.id == cid).first()
    if not c:
        raise HTTPException(status_code=404, detail="Client not found")
    c.name = name
    c.email = email
    c.booking_history = booking_history
    c.preferences = preferences
    c.feedback = feedback
    db.commit()
    return RedirectResponse("/crm", status_code=303)

@router.get("/delete/{cid}", response_class=RedirectResponse)
async def delete_client(cid: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    c = db.query(CRMClient).filter(CRMClient.id == cid).first()
    if c:
        db.delete(c)
        db.commit()
    return RedirectResponse("/crm", status_code=303)