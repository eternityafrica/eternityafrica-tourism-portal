from fastapi import APIRouter, Request, Form, Depends
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy.orm import Session
from app.models import Warehouse
from app.deps import get_db

router = APIRouter()

@router.get("/", response_class=HTMLResponse)
async def warehouse_list(request: Request, db: Session = Depends(get_db)):
    warehouses = db.query(Warehouse).order_by(Warehouse.name.asc()).all()
    return request.app.templates.TemplateResponse("warehouse.html", {"request": request, "warehouses": warehouses})

@router.get("/new", response_class=HTMLResponse)
async def warehouse_create_form(request: Request):
    return request.app.templates.TemplateResponse("warehouse_create.html", {"request": request})

@router.post("/new", response_class=RedirectResponse)
async def warehouse_create(
    name: str = Form(...),
    location: str = Form(...),
    description: str = Form(...),
    db: Session = Depends(get_db)
):
    warehouse = Warehouse(name=name, location=location, description=description)
    db.add(warehouse)
    db.commit()
    return RedirectResponse("/warehouse", status_code=303)