from fastapi import APIRouter, Request, Depends
from fastapi.responses import RedirectResponse, HTMLResponse
from app.config import GRAPH_CLIENT_ID, GRAPH_CLIENT_SECRET, GRAPH_AUTHORITY, GRAPH_REDIRECT_URI, GRAPH_SCOPES
import msal
import requests
import urllib.parse

router = APIRouter()

# Step 1: Redirect user to Microsoft login/consent
@router.get("/graph/login")
async def graph_login():
    params = {
        "client_id": GRAPH_CLIENT_ID,
        "response_type": "code",
        "redirect_uri": GRAPH_REDIRECT_URI,
        "response_mode": "query",
        "scope": " ".join(GRAPH_SCOPES),
        "state": "randomstring",  # Replace with secure random string
    }
    url = f"{GRAPH_AUTHORITY}/oauth2/v2.0/authorize?" + urllib.parse.urlencode(params)
    return RedirectResponse(url)

# Step 2: Callback to exchange code for tokens
@router.get("/graph/callback", response_class=HTMLResponse)
async def graph_callback(request: Request):
    code = request.query_params.get("code")
    state = request.query_params.get("state")
    if not code:
        return HTMLResponse("<h2>Authorization failed or denied.</h2>")
    token_url = f"{GRAPH_AUTHORITY}/oauth2/v2.0/token"
    data = {
        "client_id": GRAPH_CLIENT_ID,
        "scope": " ".join(GRAPH_SCOPES),
        "code": code,
        "redirect_uri": GRAPH_REDIRECT_URI,
        "grant_type": "authorization_code",
        "client_secret": GRAPH_CLIENT_SECRET,
    }
    resp = requests.post(token_url, data=data)
    if resp.status_code != 200:
        return HTMLResponse(f"<h2>Token exchange failed: {resp.text}</h2>")
    tokens = resp.json()
    # Save tokens (access_token, refresh_token) securely for user/session
    # For demo, show them
    return HTMLResponse(
        f"<h2>Success! Tokens acquired.</h2>"
        f"<pre>{tokens}</pre>"
        f"<br><a href='/dashboard'>Go to Dashboard</a>"
    )