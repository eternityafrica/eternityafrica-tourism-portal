from fastapi import APIRouter, Request, Form, Depends, Cookie
from fastapi.responses import HTMLResponse, RedirectResponse
from app.models import Affiliate
from app.deps import get_db

router = APIRouter()

@router.get("/settings", response_class=HTMLResponse)
async def get_settings(request: Request, db=Depends(get_db), affiliate_id: str = Cookie(None)):
    affiliate = db.query(Affiliate).filter_by(id=affiliate_id).first()
    return request.app.templates.TemplateResponse("affiliate_settings.html", {"request": request, "affiliate": affiliate})

@router.post("/settings")
async def update_settings(
    notify_payouts: bool = Form(False),
    notify_status: bool = Form(False),
    db=Depends(get_db),
    affiliate_id: str = Cookie(None)
):
    affiliate = db.query(Affiliate).filter_by(id=affiliate_id).first()
    affiliate.notify_payouts = notify_payouts
    affiliate.notify_status = notify_status
    db.commit()
    return RedirectResponse("/affiliate/settings", status_code=303)