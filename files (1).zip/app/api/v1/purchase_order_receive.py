from fastapi import APIRouter, Depends
from fastapi.responses import RedirectResponse
from sqlalchemy.orm import Session
from app.models import PurchaseOrder, PurchaseOrderItem, InventoryItem
from app.deps import get_db

router = APIRouter()

@router.post("/receive/{poid}", response_class=RedirectResponse)
async def receive_po(poid: int, db: Session = Depends(get_db)):
    po = db.query(PurchaseOrder).filter(PurchaseOrder.id == poid).first()
    if po and po.status != "Received":
        po.status = "Received"
        po.received_at = datetime.datetime.utcnow()
        po_items = db.query(PurchaseOrderItem).filter(PurchaseOrderItem.purchase_order_id == poid).all()
        for poi in po_items:
            item = db.query(InventoryItem).filter(InventoryItem.id == poi.item_id).first()
            if item:
                item.quantity += poi.quantity
        db.commit()
    return RedirectResponse("/purchase_order", status_code=303)