from fastapi import APIRouter, Request, Depends, Cookie
from sqlalchemy.orm import Session
from app.models import Affiliate, Payout
from app.deps import get_db

router = APIRouter()

@router.get("/self_dashboard", response_class=HTMLResponse)
async def affiliate_self_dashboard(request: Request, db: Session = Depends(get_db), affiliate_id: str = Cookie(None)):
    affiliate = db.query(Affiliate).filter_by(id=affiliate_id).first()
    if not affiliate:
        return HTMLResponse("<h2>Not logged in.</h2>")
    payouts = db.query(Payout).filter_by(affiliate_id=affiliate.id).order_by(Payout.created_at.desc()).all()
    return request.app.templates.TemplateResponse("affiliate_self_dashboard.html", {
        "request": request, "affiliate": affiliate, "payouts": payouts
    })