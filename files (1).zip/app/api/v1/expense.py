from fastapi import APIRouter, Request, Form, Depends, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from app.models import Expense, Staff
from app.deps import get_db
from app.auth import get_current_user
import datetime

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")

@router.get("/", response_class=HTMLResponse)
async def expense_list(request: Request, db: Session = Depends(get_db), user=Depends(get_current_user)):
    expenses = db.query(Expense).order_by(Expense.date.desc()).all()
    staff = {s.id: s for s in db.query(Staff).all()}
    return templates.TemplateResponse("expense.html", {"request": request, "expenses": expenses, "staff": staff, "user": user})

@router.get("/new", response_class=HTMLResponse)
async def expense_create_form(request: Request, db: Session = Depends(get_db), user=Depends(get_current_user)):
    staff_list = db.query(Staff).filter_by(is_active=True).all()
    return templates.TemplateResponse("expense_create.html", {"request": request, "staff_list": staff_list, "user": user})

@router.post("/new", response_class=RedirectResponse)
async def expense_create(
    description: str = Form(...),
    amount: int = Form(...),
    staff_id: int = Form(None),
    category: str = Form(...),
    date: str = Form(...),
    db: Session = Depends(get_db),
    user=Depends(get_current_user)
):
    expense = Expense(
        description=description,
        amount=amount,
        staff_id=staff_id,
        category=category,
        date=datetime.datetime.fromisoformat(date)
    )
    db.add(expense)
    db.commit()
    return RedirectResponse("/expense", status_code=303)

@router.get("/edit/{eid}", response_class=HTMLResponse)
async def expense_edit_form(request: Request, eid: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    expense = db.query(Expense).filter(Expense.id == eid).first()
    staff_list = db.query(Staff).filter_by(is_active=True).all()
    if not expense:
        raise HTTPException(status_code=404, detail="Expense not found")
    return templates.TemplateResponse("expense_edit.html", {"request": request, "expense": expense, "staff_list": staff_list, "user": user})

@router.post("/edit/{eid}", response_class=RedirectResponse)
async def expense_update(
    eid: int,
    description: str = Form(...),
    amount: int = Form(...),
    staff_id: int = Form(None),
    category: str = Form(...),
    date: str = Form(...),
    db: Session = Depends(get_db),
    user=Depends(get_current_user)
):
    expense = db.query(Expense).filter(Expense.id == eid).first()
    if not expense:
        raise HTTPException(status_code=404, detail="Expense not found")
    expense.description = description
    expense.amount = amount
    expense.staff_id = staff_id
    expense.category = category
    expense.date = datetime.datetime.fromisoformat(date)
    db.commit()
    return RedirectResponse("/expense", status_code=303)

@router.get("/delete/{eid}", response_class=RedirectResponse)
async def expense_delete(eid: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    expense = db.query(Expense).filter(Expense.id == eid).first()
    if expense:
        db.delete(expense)
        db.commit()
    return RedirectResponse("/expense", status_code=303)