@router.get("/summary", response_class=HTMLResponse)
async def affiliate_summary(request: Request, db: Session = Depends(get_db), affiliate_id: int = None, status: str = None):
    query = db.query(Referral)
    if affiliate_id:
        query = query.filter(Referral.affiliate_id == affiliate_id)
    if status:
        query = query.filter(Referral.status == status)
    referrals = query.all()
    # Aggregate as needed...
    affiliates = db.query(Affiliate).all()
    return request.app.templates.TemplateResponse("affiliate_report.html", {
        "request": request, "referrals": referrals, "affiliates": affiliates, "selected_affiliate": affiliate_id, "selected_status": status
    })