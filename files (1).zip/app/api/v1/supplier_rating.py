from fastapi import APIRouter, Form, Depends, Request
from fastapi.responses import RedirectResponse, HTMLResponse
from sqlalchemy.orm import Session
from app.models import Supplier, SupplierRating
from app.deps import get_db

router = APIRouter()

@router.get("/rate/{sid}", response_class=HTMLResponse)
async def rate_form(request: Request, sid: int, db: Session = Depends(get_db)):
    supplier = db.query(Supplier).filter(Supplier.id == sid).first()
    return request.app.templates.TemplateResponse("supplier_rate.html", {"request": request, "supplier": supplier})

@router.post("/rate/{sid}", response_class=RedirectResponse)
async def rate_supplier(sid: int, rating: int = Form(...), comments: str = Form(...), created_by: str = Form(...), db: Session = Depends(get_db)):
    rate = SupplierRating(
        supplier_id=sid,
        rating=rating,
        comments=comments,
        created_by=created_by
    )
    db.add(rate)
    db.commit()
    return RedirectResponse("/supplier", status_code=303)