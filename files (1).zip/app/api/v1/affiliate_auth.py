@router.get("/signup", response_class=HTMLResponse)
async def affiliate_signup_form(request: Request):
    return request.app.templates.TemplateResponse("affiliate_signup.html", {"request": request})

@router.post("/signup")
async def affiliate_signup(
    name: str = Form(...),
    contact_email: str = Form(...),
    password: str = Form(...),
    referral_code: str = Form(...),
    website: str = Form(...),
    db: Session = Depends(get_db)
):
    password_hash = bcrypt.hash(password)
    affiliate = Affiliate(
        name=name, contact_email=contact_email, password_hash=password_hash,
        referral_code=referral_code, website=website, is_active=True)
    db.add(affiliate)
    db.commit()
    return RedirectResponse("/affiliate/login", status_code=303)