from fastapi import APIRouter, Request, Form, Depends, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from app.models import Expense
from app.deps import get_db
from app.auth import get_current_user

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")

@router.get("/", response_class=HTMLResponse)
async def finance_list(request: Request, db: Session = Depends(get_db), user=Depends(get_current_user)):
    expenses = db.query(Expense).all()
    return templates.TemplateResponse("finance.html", {"request": request, "expenses": expenses, "user": user})

@router.get("/new", response_class=HTMLResponse)
async def create_expense_form(request: Request, user=Depends(get_current_user)):
    return templates.TemplateResponse("finance_create.html", {"request": request, "user": user})

@router.post("/new", response_class=RedirectResponse)
async def create_expense(
    description: str = Form(...),
    amount: float = Form(...),
    status: str = Form(...),
    db: Session = Depends(get_db),
    user=Depends(get_current_user)
):
    e = Expense(description=description, amount=amount, status=status)
    db.add(e)
    db.commit()
    return RedirectResponse("/finance", status_code=303)

@router.get("/edit/{eid}", response_class=HTMLResponse)
async def edit_expense(request: Request, eid: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    expense = db.query(Expense).filter(Expense.id == eid).first()
    if not expense:
        raise HTTPException(status_code=404, detail="Expense not found")
    return templates.TemplateResponse("finance_edit.html", {"request": request, "expense": expense, "user": user})

@router.post("/edit/{eid}", response_class=RedirectResponse)
async def update_expense(
    eid: int,
    description: str = Form(...),
    amount: float = Form(...),
    status: str = Form(...),
    db: Session = Depends(get_db),
    user=Depends(get_current_user)
):
    expense = db.query(Expense).filter(Expense.id == eid).first()
    if not expense:
        raise HTTPException(status_code=404, detail="Expense not found")
    expense.description = description
    expense.amount = amount
    expense.status = status
    db.commit()
    return RedirectResponse("/finance", status_code=303)

@router.get("/delete/{eid}", response_class=RedirectResponse)
async def delete_expense(eid: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    expense = db.query(Expense).filter(Expense.id == eid).first()
    if expense:
        db.delete(expense)
        db.commit()
    return RedirectResponse("/finance", status_code=303)