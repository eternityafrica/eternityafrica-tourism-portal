from fastapi import APIRouter, Depends
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session
from app.models import Payout, Affiliate
from app.deps import get_db
import io
import csv

router = APIRouter()

@router.get("/payouts/export", response_class=StreamingResponse)
async def export_payouts_csv(db: Session = Depends(get_db)):
    payouts = db.query(Payout).order_by(Payout.created_at.desc()).all()
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["Affiliate", "Amount", "Period Start", "Period End", "Gateway", "Gateway ID", "Status", "Created At"])
    for p in payouts:
        affiliate = db.query(Affiliate).filter_by(id=p.affiliate_id).first()
        writer.writerow([
            affiliate.name if affiliate else "",
            p.amount,
            p.period_start.strftime('%Y-%m-%d'),
            p.period_end.strftime('%Y-%m-%d'),
            p.gateway,
            p.gateway_id,
            p.status,
            p.created_at.strftime('%Y-%m-%d %H:%M')
        ])
    output.seek(0)
    headers = {"Content-Disposition": "attachment; filename=payout_history.csv"}
    return StreamingResponse(output, media_type="text/csv", headers=headers)