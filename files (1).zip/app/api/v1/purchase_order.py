from fastapi import APIRouter, Request, Form, Depends
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from app.models import PurchaseOrder, PurchaseOrderItem, Supplier, InventoryItem
from app.deps import get_db
import datetime

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")

@router.get("/", response_class=HTMLResponse)
async def po_list(request: Request, db: Session = Depends(get_db)):
    orders = db.query(PurchaseOrder).order_by(PurchaseOrder.order_date.desc()).all()
    suppliers = {s.id: s for s in db.query(Supplier).all()}
    return templates.TemplateResponse("purchase_order.html", {"request": request, "orders": orders, "suppliers": suppliers})

@router.get("/new", response_class=HTMLResponse)
async def po_create_form(request: Request, db: Session = Depends(get_db)):
    suppliers = db.query(Supplier).all()
    items = db.query(InventoryItem).all()
    return templates.TemplateResponse("purchase_order_create.html", {"request": request, "suppliers": suppliers, "items": items})

@router.post("/new", response_class=RedirectResponse)
async def po_create(
    supplier_id: int = Form(...),
    expected_date: str = Form(None),
    status: str = Form(...),
    notes: str = Form(...),
    db: Session = Depends(get_db)
):
    po = PurchaseOrder(
        supplier_id=supplier_id,
        expected_date=datetime.datetime.fromisoformat(expected_date) if expected_date else None,
        status=status,
        notes=notes
    )
    db.add(po)
    db.commit()
    return RedirectResponse("/purchase_order", status_code=303)

@router.get("/edit/{poid}", response_class=HTMLResponse)
async def po_edit_form(request: Request, poid: int, db: Session = Depends(get_db)):
    po = db.query(PurchaseOrder).filter(PurchaseOrder.id == poid).first()
    suppliers = db.query(Supplier).all()
    items = db.query(InventoryItem).all()
    po_items = db.query(PurchaseOrderItem).filter(PurchaseOrderItem.purchase_order_id == poid).all()
    return templates.TemplateResponse("purchase_order_edit.html", {
        "request": request,
        "po": po,
        "suppliers": suppliers,
        "items": items,
        "po_items": po_items
    })