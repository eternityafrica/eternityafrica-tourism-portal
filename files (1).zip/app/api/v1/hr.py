from fastapi import APIRouter, Request, Form, Depends, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from app.models import Staff
from app.deps import get_db
from app.auth import get_current_user

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")

@router.get("/", response_class=HTMLResponse)
async def hr_list(request: Request, db: Session = Depends(get_db), user=Depends(get_current_user)):
    staff = db.query(Staff).all()
    return templates.TemplateResponse("hr.html", {"request": request, "staff": staff, "user": user})

@router.get("/new", response_class=HTMLResponse)
async def create_staff_form(request: Request, user=Depends(get_current_user)):
    return templates.TemplateResponse("hr_create.html", {"request": request, "user": user})

@router.post("/new", response_class=RedirectResponse)
async def create_staff(
    name: str = Form(...),
    role: str = Form(...),
    email: str = Form(...),
    is_active: bool = Form(...),
    db: Session = Depends(get_db),
    user=Depends(get_current_user)
):
    s = Staff(name=name, role=role, email=email, is_active=is_active)
    db.add(s)
    db.commit()
    return RedirectResponse("/hr", status_code=303)

@router.get("/edit/{sid}", response_class=HTMLResponse)
async def edit_staff(request: Request, sid: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    staff = db.query(Staff).filter(Staff.id == sid).first()
    if not staff:
        raise HTTPException(status_code=404, detail="Staff not found")
    return templates.TemplateResponse("hr_edit.html", {"request": request, "staff": staff, "user": user})

@router.post("/edit/{sid}", response_class=RedirectResponse)
async def update_staff(
    sid: int,
    name: str = Form(...),
    role: str = Form(...),
    email: str = Form(...),
    is_active: bool = Form(...),
    db: Session = Depends(get_db),
    user=Depends(get_current_user)
):
    staff = db.query(Staff).filter(Staff.id == sid).first()
    if not staff:
        raise HTTPException(status_code=404, detail="Staff not found")
    staff.name = name
    staff.role = role
    staff.email = email
    staff.is_active = is_active
    db.commit()
    return RedirectResponse("/hr", status_code=303)

@router.get("/delete/{sid}", response_class=RedirectResponse)
async def delete_staff(sid: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    staff = db.query(Staff).filter(Staff.id == sid).first()
    if staff:
        db.delete(staff)
        db.commit()
    return RedirectResponse("/hr", status_code=303)