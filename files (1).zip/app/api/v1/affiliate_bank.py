@router.get("/bank", response_class=HTMLResponse)
async def bank_info_form(request: Request, db=Depends(get_db), affiliate_id: str = Cookie(None)):
    affiliate = db.query(Affiliate).filter_by(id=affiliate_id).first()
    return request.app.templates.TemplateResponse("affiliate_bank.html", {"request": request, "affiliate": affiliate})

@router.post("/bank")
async def update_bank_info(
    bank_account_name: str = Form(...),
    bank_account_number: str = Form(...),
    bank_name: str = Form(...),
    bank_swift_code: str = Form(...),
    db=Depends(get_db),
    affiliate_id: str = Cookie(None)
):
    affiliate = db.query(Affiliate).filter_by(id=affiliate_id).first()
    affiliate.bank_account_name = bank_account_name
    affiliate.bank_account_number = bank_account_number
    affiliate.bank_name = bank_name
    affiliate.bank_swift_code = bank_swift_code
    db.commit()
    return RedirectResponse("/affiliate/bank", status_code=303)