from fastapi import APIRouter, Request, Form, Depends, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from app.models import RoutePlan
from app.deps import get_db
from app.auth import get_current_user

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")

@router.get("/", response_class=HTMLResponse)
async def route_plan_list(request: Request, db: Session = Depends(get_db), user=Depends(get_current_user)):
    plans = db.query(RoutePlan).all()
    return templates.TemplateResponse("route_plans.html", {"request": request, "plans": plans, "user": user})

@router.get("/new", response_class=HTMLResponse)
async def create_route_form(request: Request, user=Depends(get_current_user)):
    return templates.TemplateResponse("route_plan_create.html", {"request": request, "user": user})

@router.post("/new", response_class=RedirectResponse)
async def create_route(
    title: str = Form(...),
    start_location: str = Form(...),
    end_location: str = Form(...),
    waypoints: str = Form(...),
    notes: str = Form(...),
    db: Session = Depends(get_db),
    user=Depends(get_current_user)
):
    rp = RoutePlan(title=title, start_location=start_location, end_location=end_location, waypoints=waypoints, notes=notes)
    db.add(rp)
    db.commit()
    return RedirectResponse("/route_planning", status_code=303)

@router.get("/edit/{rid}", response_class=HTMLResponse)
async def edit_route(request: Request, rid: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    rp = db.query(RoutePlan).filter(RoutePlan.id == rid).first()
    if not rp:
        raise HTTPException(status_code=404, detail="Route not found")
    return templates.TemplateResponse("route_plan_edit.html", {"request": request, "route": rp, "user": user})

@router.post("/edit/{rid}", response_class=RedirectResponse)
async def update_route(
    rid: int,
    title: str = Form(...),
    start_location: str = Form(...),
    end_location: str = Form(...),
    waypoints: str = Form(...),
    notes: str = Form(...),
    db: Session = Depends(get_db),
    user=Depends(get_current_user)
):
    rp = db.query(RoutePlan).filter(RoutePlan.id == rid).first()
    if not rp:
        raise HTTPException(status_code=404, detail="Route not found")
    rp.title = title
    rp.start_location = start_location
    rp.end_location = end_location
    rp.waypoints = waypoints
    rp.notes = notes
    db.commit()
    return RedirectResponse("/route_planning", status_code=303)

@router.get("/delete/{rid}", response_class=RedirectResponse)
async def delete_route(rid: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    rp = db.query(RoutePlan).filter(RoutePlan.id == rid).first()
    if rp:
        db.delete(rp)
        db.commit()
    return RedirectResponse("/route_planning", status_code=303)