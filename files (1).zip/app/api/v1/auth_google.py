from fastapi import APIRouter, Request, Depends
from fastapi.responses import RedirectResponse, HTMLResponse
from app.config import GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET, GOOGLE_REDIRECT_URI, GOOGLE_SCOPES
from app.models import OAuthToken, User
from app.deps import get_db
import requests, urllib.parse, datetime

router = APIRouter()

@router.get("/google/login")
async def google_login():
    params = {
        "client_id": GOOGLE_CLIENT_ID,
        "response_type": "code",
        "redirect_uri": GOOGLE_REDIRECT_URI,
        "scope": " ".join(GOOGLE_SCOPES),
        "access_type": "offline",
        "prompt": "consent"
    }
    url = "https://accounts.google.com/o/oauth2/v2/auth?" + urllib.parse.urlencode(params)
    return RedirectResponse(url)

@router.get("/google/callback")
async def google_callback(request: Request, db=Depends(get_db)):
    code = request.query_params.get("code")
    if not code:
        return HTMLResponse("<h2>Authorization failed or denied.</h2>")
    # Exchange code for tokens
    resp = requests.post(
        "https://oauth2.googleapis.com/token",
        data={
            "client_id": GOOGLE_CLIENT_ID,
            "client_secret": GOOGLE_CLIENT_SECRET,
            "code": code,
            "redirect_uri": GOOGLE_REDIRECT_URI,
            "grant_type": "authorization_code"
        }
    )
    if resp.status_code != 200:
        return HTMLResponse(f"<h2>Token exchange failed: {resp.text}</h2>")
    tokens = resp.json()
    # Get user info for association
    userinfo_resp = requests.get(
        "https://www.googleapis.com/oauth2/v2/userinfo",
        headers={"Authorization": f"Bearer {tokens['access_token']}"}
    )
    userinfo = userinfo_resp.json()
    user = db.query(User).filter_by(email=userinfo["email"]).first()
    if not user:
        user = User(email=userinfo["email"])
        db.add(user)
        db.commit()
    # Store tokens securely
    expires_at = datetime.datetime.utcnow() + datetime.timedelta(seconds=int(tokens["expires_in"]))
    oauth_token = OAuthToken(
        user_id=user.id,
        provider="google",
        access_token=tokens["access_token"],
        refresh_token=tokens.get("refresh_token"),
        expires_at=expires_at
    )
    db.add(oauth_token)
    db.commit()
    return HTMLResponse("<h2>Google Calendar connected!</h2><a href='/dashboard'>Go to Dashboard</a>")