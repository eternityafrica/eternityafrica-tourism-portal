import stripe
from fastapi import APIRouter, Request, Header, Depends
import os

router = APIRouter()
endpoint_secret = os.getenv("STRIPE_WEBHOOK_SECRET")

@router.post("/stripe/webhook")
async def stripe_webhook(request: Request, stripe_signature: str = Header(None), db=Depends(get_db)):
    payload = await request.body()
    try:
        event = stripe.Webhook.construct_event(
            payload=payload,
            sig_header=stripe_signature,
            secret=endpoint_secret
        )
    except stripe.error.SignatureVerificationError as e:
        # Invalid signature
        return {"error": "Invalid signature"}
    except Exception as e:
        return {"error": str(e)}

    # process event...
    return {"received": True}