from fastapi import APIRouter, Request, Form, Depends, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from app.models import Report
from app.deps import get_db
from app.auth import get_current_user

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")

@router.get("/", response_class=HTMLResponse)
async def reporting_list(request: Request, db: Session = Depends(get_db), user=Depends(get_current_user)):
    reports = db.query(Report).order_by(Report.created_at.desc()).all()
    return templates.TemplateResponse("reporting.html", {"request": request, "reports": reports, "user": user})

@router.get("/new", response_class=HTMLResponse)
async def create_report_form(request: Request, user=Depends(get_current_user)):
    return templates.TemplateResponse("reporting_create.html", {"request": request, "user": user})

@router.post("/new", response_class=RedirectResponse)
async def create_report(
    department: str = Form(...),
    title: str = Form(...),
    data: str = Form(...),
    db: Session = Depends(get_db),
    user=Depends(get_current_user)
):
    r = Report(department=department, title=title, data=data)
    db.add(r)
    db.commit()
    return RedirectResponse("/reporting", status_code=303)

@router.get("/edit/{rid}", response_class=HTMLResponse)
async def edit_report(request: Request, rid: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    r = db.query(Report).filter(Report.id == rid).first()
    if not r:
        raise HTTPException(status_code=404, detail="Report not found")
    return templates.TemplateResponse("reporting_edit.html", {"request": request, "r": r, "user": user})

@router.post("/edit/{rid}", response_class=RedirectResponse)
async def update_report(
    rid: int,
    department: str = Form(...),
    title: str = Form(...),
    data: str = Form(...),
    db: Session = Depends(get_db),
    user=Depends(get_current_user)
):
    r = db.query(Report).filter(Report.id == rid).first()
    if not r:
        raise HTTPException(status_code=404, detail="Report not found")
    r.department = department
    r.title = title
    r.data = data
    db.commit()
    return RedirectResponse("/reporting", status_code=303)

@router.get("/delete/{rid}", response_class=RedirectResponse)
async def delete_report(rid: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    r = db.query(Report).filter(Report.id == rid).first()
    if r:
        db.delete(r)
        db.commit()
    return RedirectResponse("/reporting", status_code=303)