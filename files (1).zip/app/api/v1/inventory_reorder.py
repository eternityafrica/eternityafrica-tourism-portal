from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.models import InventoryItem
from app.deps import get_db

router = APIRouter()

@router.get("/reorder", response_class=HTMLResponse)
async def inventory_reorder(request: Request, db: Session = Depends(get_db)):
    items = db.query(InventoryItem).filter(InventoryItem.quantity <= InventoryItem.reorder_point).all()
    return request.app.templates.TemplateResponse("inventory_reorder.html", {"request": request, "items": items})