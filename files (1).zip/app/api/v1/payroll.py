from fastapi import APIRouter, Request, Form, Depends, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from app.models import Payroll, Staff
from app.deps import get_db
from app.auth import get_current_user
import datetime

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")

@router.get("/", response_class=HTMLResponse)
async def payroll_list(request: Request, db: Session = Depends(get_db), user=Depends(get_current_user)):
    payrolls = db.query(Payroll).order_by(Payroll.month.desc()).all()
    staff = {s.id: s for s in db.query(Staff).all()}
    return templates.TemplateResponse("payroll.html", {"request": request, "payrolls": payrolls, "staff": staff, "user": user})

@router.get("/new", response_class=HTMLResponse)
async def payroll_create_form(request: Request, db: Session = Depends(get_db), user=Depends(get_current_user)):
    staff_list = db.query(Staff).filter_by(is_active=True).all()
    return templates.TemplateResponse("payroll_create.html", {"request": request, "staff_list": staff_list, "user": user})

@router.post("/new", response_class=RedirectResponse)
async def payroll_create(
    staff_id: int = Form(...),
    month: str = Form(...),
    amount: int = Form(...),
    status: str = Form(...),
    db: Session = Depends(get_db),
    user=Depends(get_current_user)
):
    payroll = Payroll(
        staff_id=staff_id,
        month=month,
        amount=amount,
        status=status,
        paid_at=datetime.datetime.utcnow() if status == "Paid" else None
    )
    db.add(payroll)
    db.commit()
    return RedirectResponse("/payroll", status_code=303)

@router.get("/edit/{pid}", response_class=HTMLResponse)
async def payroll_edit_form(request: Request, pid: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    payroll = db.query(Payroll).filter(Payroll.id == pid).first()
    staff_list = db.query(Staff).filter_by(is_active=True).all()
    if not payroll:
        raise HTTPException(status_code=404, detail="Payroll record not found")
    return templates.TemplateResponse("payroll_edit.html", {"request": request, "payroll": payroll, "staff_list": staff_list, "user": user})

@router.post("/edit/{pid}", response_class=RedirectResponse)
async def payroll_update(
    pid: int,
    staff_id: int = Form(...),
    month: str = Form(...),
    amount: int = Form(...),
    status: str = Form(...),
    db: Session = Depends(get_db),
    user=Depends(get_current_user)
):
    payroll = db.query(Payroll).filter(Payroll.id == pid).first()
    if not payroll:
        raise HTTPException(status_code=404, detail="Payroll record not found")
    payroll.staff_id = staff_id
    payroll.month = month
    payroll.amount = amount
    payroll.status = status
    payroll.paid_at = datetime.datetime.utcnow() if status == "Paid" else None
    db.commit()
    return RedirectResponse("/payroll", status_code=303)

@router.get("/delete/{pid}", response_class=RedirectResponse)
async def payroll_delete(pid: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    payroll = db.query(Payroll).filter(Payroll.id == pid).first()
    if payroll:
        db.delete(payroll)
        db.commit()
    return RedirectResponse("/payroll", status_code=303)