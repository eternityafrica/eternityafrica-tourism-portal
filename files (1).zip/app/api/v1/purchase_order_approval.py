from fastapi import APIRouter, Form, Depends, Request
from fastapi.responses import RedirectResponse, HTMLResponse
from sqlalchemy.orm import Session
from app.models import PurchaseOrder
from app.deps import get_db

router = APIRouter()

@router.get("/approve/{poid}", response_class=HTMLResponse)
async def approve_form(request: Request, poid: int, db: Session = Depends(get_db)):
    po = db.query(PurchaseOrder).filter(PurchaseOrder.id == poid).first()
    return request.app.templates.TemplateResponse("purchase_order_approve.html", {"request": request, "po": po})

@router.post("/approve/{poid}", response_class=RedirectResponse)
async def approve_po(poid: int, action: str = Form(...), approved_by: str = Form(...), rejected_reason: str = Form(""), db: Session = Depends(get_db)):
    po = db.query(PurchaseOrder).filter(PurchaseOrder.id == poid).first()
    if action == "approve":
        po.approval_status = "Approved"
        po.approved_by = approved_by
        po.approved_at = datetime.datetime.utcnow()
        po.rejected_reason = None
    else:
        po.approval_status = "Rejected"
        po.approved_by = approved_by
        po.approved_at = datetime.datetime.utcnow()
        po.rejected_reason = rejected_reason
    db.commit()
    return RedirectResponse("/purchase_order", status_code=303)