from fastapi import APIRouter, Request, Form, Depends, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from app.models import OnlineTour
from app.deps import get_db
from app.auth import get_current_user
import json

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")

@router.get("/", response_class=HTMLResponse)
async def sales_list(request: Request, db: Session = Depends(get_db), user=Depends(get_current_user)):
    tours = db.query(OnlineTour).all()
    return templates.TemplateResponse("online_sales.html", {"request": request, "tours": tours, "user": user})

@router.get("/new", response_class=HTMLResponse)
async def create_tour_form(request: Request, user=Depends(get_current_user)):
    return templates.TemplateResponse("online_sales_create.html", {"request": request, "user": user})

@router.post("/new", response_class=RedirectResponse)
async def create_tour(
    title: str = Form(...),
    description: str = Form(...),
    itinerary: str = Form(...),
    pricing: float = Form(...),
    media_url: str = Form(...),
    ota_links: str = Form(...),
    is_active: bool = Form(...),
    db: Session = Depends(get_db),
    user=Depends(get_current_user)
):
    t = OnlineTour(
        title=title,
        description=description,
        itinerary=itinerary,
        pricing=pricing,
        media_url=media_url,
        ota_links=ota_links,
        is_active=is_active
    )
    db.add(t)
    db.commit()
    return RedirectResponse("/online_sales", status_code=303)

@router.get("/edit/{tid}", response_class=HTMLResponse)
async def edit_tour(request: Request, tid: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    t = db.query(OnlineTour).filter(OnlineTour.id == tid).first()
    if not t:
        raise HTTPException(status_code=404, detail="Tour not found")
    return templates.TemplateResponse("online_sales_edit.html", {"request": request, "tour": t, "user": user})

@router.post("/edit/{tid}", response_class=RedirectResponse)
async def update_tour(
    tid: int,
    title: str = Form(...),
    description: str = Form(...),
    itinerary: str = Form(...),
    pricing: float = Form(...),
    media_url: str = Form(...),
    ota_links: str = Form(...),
    is_active: bool = Form(...),
    db: Session = Depends(get_db),
    user=Depends(get_current_user)
):
    t = db.query(OnlineTour).filter(OnlineTour.id == tid).first()
    if not t:
        raise HTTPException(status_code=404, detail="Tour not found")
    t.title = title
    t.description = description
    t.itinerary = itinerary
    t.pricing = pricing
    t.media_url = media_url
    t.ota_links = ota_links
    t.is_active = is_active
    db.commit()
    return RedirectResponse("/online_sales", status_code=303)

@router.get("/delete/{tid}", response_class=RedirectResponse)
async def delete_tour(tid: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    t = db.query(OnlineTour).filter(OnlineTour.id == tid).first()
    if t:
        db.delete(t)
        db.commit()
    return RedirectResponse("/online_sales", status_code=303)