from fastapi import APIRouter, Request, Form, Depends, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from app.models import Supplier
from app.deps import get_db

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")

@router.get("/", response_class=HTMLResponse)
async def supplier_list(request: Request, db: Session = Depends(get_db)):
    suppliers = db.query(Supplier).order_by(Supplier.name.asc()).all()
    return templates.TemplateResponse("supplier.html", {"request": request, "suppliers": suppliers})

@router.get("/new", response_class=HTMLResponse)
async def supplier_create_form(request: Request):
    return templates.TemplateResponse("supplier_create.html", {"request": request})

@router.post("/new", response_class=RedirectResponse)
async def supplier_create(
    name: str = Form(...),
    contact_person: str = Form(...),
    email: str = Form(...),
    phone: str = Form(...),
    address: str = Form(...),
    notes: str = Form(...),
    db: Session = Depends(get_db)
):
    supplier = Supplier(
        name=name,
        contact_person=contact_person,
        email=email,
        phone=phone,
        address=address,
        notes=notes
    )
    db.add(supplier)
    db.commit()
    return RedirectResponse("/supplier", status_code=303)

@router.get("/edit/{sid}", response_class=HTMLResponse)
async def supplier_edit_form(request: Request, sid: int, db: Session = Depends(get_db)):
    supplier = db.query(Supplier).filter(Supplier.id == sid).first()
    if not supplier:
        raise HTTPException(status_code=404, detail="Supplier not found")
    return templates.TemplateResponse("supplier_edit.html", {"request": request, "supplier": supplier})

@router.post("/edit/{sid}", response_class=RedirectResponse)
async def supplier_update(
    sid: int,
    name: str = Form(...),
    contact_person: str = Form(...),
    email: str = Form(...),
    phone: str = Form(...),
    address: str = Form(...),
    notes: str = Form(...),
    db: Session = Depends(get_db)
):
    supplier = db.query(Supplier).filter(Supplier.id == sid).first()
    if not supplier:
        raise HTTPException(status_code=404, detail="Supplier not found")
    supplier.name = name
    supplier.contact_person = contact_person
    supplier.email = email
    supplier.phone = phone
    supplier.address = address
    supplier.notes = notes
    db.commit()
    return RedirectResponse("/supplier", status_code=303)

@router.get("/delete/{sid}", response_class=RedirectResponse)
async def supplier_delete(sid: int, db: Session = Depends(get_db)):
    supplier = db.query(Supplier).filter(Supplier.id == sid).first()
    if supplier:
        db.delete(supplier)
        db.commit()
    return RedirectResponse("/supplier", status_code=303)