from fastapi import APIRouter, Request, Form, Depends, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from app.models import Feedback
from app.deps import get_db
from app.auth import get_current_user

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")

@router.get("/", response_class=HTMLResponse)
async def feedback_list(request: Request, db: Session = Depends(get_db), user=Depends(get_current_user)):
    feedbacks = db.query(Feedback).order_by(Feedback.submitted_at.desc()).all()
    return templates.TemplateResponse("feedback.html", {"request": request, "feedbacks": feedbacks, "user": user})

@router.get("/new", response_class=HTMLResponse)
async def create_feedback_form(request: Request):
    return templates.TemplateResponse("feedback_create.html", {"request": request})

@router.post("/new", response_class=RedirectResponse)
async def create_feedback(
    client_name: str = Form(...),
    email: str = Form(...),
    rating: int = Form(...),
    comments: str = Form(...),
    db: Session = Depends(get_db)
):
    feedback = Feedback(client_name=client_name, email=email, rating=rating, comments=comments)
    db.add(feedback)
    db.commit()
    return RedirectResponse("/feedback", status_code=303)

@router.get("/resolve/{fid}", response_class=RedirectResponse)
async def resolve_feedback(fid: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    feedback = db.query(Feedback).filter(Feedback.id == fid).first()
    if feedback:
        feedback.resolved = True
        db.commit()
    return RedirectResponse("/feedback", status_code=303)

@router.get("/delete/{fid}", response_class=RedirectResponse)
async def delete_feedback(fid: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    feedback = db.query(Feedback).filter(Feedback.id == fid).first()
    if feedback:
        db.delete(feedback)
        db.commit()
    return RedirectResponse("/feedback", status_code=303)