import requests
from fastapi import APIRouter, Request, Header, Depends
import os

router = APIRouter()

PAYPAL_CLIENT_ID = os.getenv("PAYPAL_CLIENT_ID")
PAYPAL_CLIENT_SECRET = os.getenv("PAYPAL_CLIENT_SECRET")

def get_paypal_access_token():
    resp = requests.post(
        "https://api.paypal.com/v1/oauth2/token",
        headers={"Accept": "application/json"},
        auth=(PAYPAL_CLIENT_ID, PAYPAL_CLIENT_SECRET),
        data={"grant_type": "client_credentials"}
    )
    return resp.json()["access_token"]

@router.post("/paypal/webhook")
async def paypal_webhook(
    request: Request,
    paypal_transmission_id: str = Header(None, alias="Paypal-Transmission-Id"),
    paypal_transmission_sig: str = Header(None, alias="Paypal-Transmission-Sig"),
    paypal_cert_url: str = Header(None, alias="Paypal-Cert-Url"),
    paypal_auth_algo: str = Header(None, alias="Paypal-Auth-Algo"),
    paypal_webhook_id: str = Header(None, alias="Paypal-Webhook-Id"),
    db=Depends(get_db)
):
    body = await request.body()
    access_token = get_paypal_access_token()
    verify_resp = requests.post(
        "https://api.paypal.com/v1/notifications/verify-webhook-signature",
        headers={"Content-Type": "application/json", "Authorization": f"Bearer {access_token}"},
        json={
            "transmission_id": paypal_transmission_id,
            "transmission_sig": paypal_transmission_sig,
            "cert_url": paypal_cert_url,
            "auth_algo": paypal_auth_algo,
            "webhook_id": paypal_webhook_id,
            "webhook_event": body.decode()
        }
    )
    if verify_resp.json().get("verification_status") != "SUCCESS":
        return {"error": "Invalid signature"}
    # process event...
    return {"received": True}