from fastapi import APIRouter, Form, Depends, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy.orm import Session
from app.models import PayoutDispute
from app.deps import get_db

router = APIRouter()

@router.get("/admin/disputes", response_class=HTMLResponse)
async def list_disputes(request: Request, db=Depends(get_db)):
    disputes = db.query(PayoutDispute).filter(PayoutDispute.status.in_(["Open", "Under Review"])).order_by(PayoutDispute.created_at.desc()).all()
    return request.app.templates.TemplateResponse("admin_disputes.html", {"request": request, "disputes": disputes})

@router.get("/admin/disputes/resolve/{dispute_id}", response_class=HTMLResponse)
async def resolve_dispute_form(request: Request, dispute_id: int, db=Depends(get_db)):
    dispute = db.query(PayoutDispute).filter_by(id=dispute_id).first()
    return request.app.templates.TemplateResponse("dispute_resolve.html", {"request": request, "dispute": dispute})

@router.post("/admin/disputes/resolve/{dispute_id}")
async def resolve_dispute(dispute_id: int, resolution: str = Form(...), status: str = Form(...), db=Depends(get_db)):
    dispute = db.query(PayoutDispute).filter_by(id=dispute_id).first()
    dispute.resolution = resolution
    dispute.status = status
    dispute.resolved_at = datetime.datetime.utcnow()
    db.commit()
    return RedirectResponse("/admin/disputes", status_code=303)