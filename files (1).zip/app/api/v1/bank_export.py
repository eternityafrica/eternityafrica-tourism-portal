from fastapi import APIRouter, Depends
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session
from app.models import Affiliate
from app.deps import get_db
import io
import csv

router = APIRouter()

@router.get("/bank/export", response_class=StreamingResponse)
async def export_bank_csv(db: Session = Depends(get_db)):
    affiliates = db.query(Affiliate).filter(Affiliate.bank_account_number != None).all()
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow([
        "Affiliate Name", "Email", "Bank Name", "Account Name", "Account Number", "SWIFT Code"
    ])
    for a in affiliates:
        writer.writerow([
            a.name,
            a.contact_email,
            a.bank_name or "",
            a.bank_account_name or "",
            a.bank_account_number or "",
            a.bank_swift_code or ""
        ])
    output.seek(0)
    headers = {"Content-Disposition": "attachment; filename=affiliate_bank_info.csv"}
    return StreamingResponse(output, media_type="text/csv", headers=headers)