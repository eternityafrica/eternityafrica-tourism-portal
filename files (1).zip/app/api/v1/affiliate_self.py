@router.get("/self_dashboard", response_class=HTMLResponse)
async def affiliate_self_dashboard(request: Request, db: Session = Depends(get_db), code: str = None):
    affiliate = db.query(Affiliate).filter_by(referral_code=code).first()
    if not affiliate:
        return HTMLResponse("<h2>Invalid referral code.</h2>")
    referrals = db.query(Referral).filter_by(affiliate_id=affiliate.id).all()
    stats = {
        "total_referrals": len(referrals),
        "confirmed": sum(1 for r in referrals if r.status == "Confirmed"),
        "paid": sum(1 for r in referrals if r.status == "Paid"),
    }
    return request.app.templates.TemplateResponse("affiliate_self_dashboard.html", {
        "request": request, "affiliate": affiliate, "referrals": referrals, "stats": stats
    })