from fastapi import APIRouter, Request, Form, Depends, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from app.models import Booking
from app.deps import get_db
from app.auth import get_current_user

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")

@router.get("/", response_class=HTMLResponse)
async def booking_list(request: Request, db: Session = Depends(get_db), user=Depends(get_current_user)):
    bookings = db.query(Booking).all()
    return templates.TemplateResponse("bookings.html", {"request": request, "bookings": bookings, "user": user})

@router.get("/new", response_class=HTMLResponse)
async def create_booking_form(request: Request, user=Depends(get_current_user)):
    packages = ["Serengeti Safari", "Kilimanjaro Trek"]  # Ideally fetched from DB
    return templates.TemplateResponse("bookings_create.html", {"request": request, "packages": packages, "user": user})

@router.post("/new", response_class=RedirectResponse)
async def create_booking(
    client: str = Form(...),
    package: str = Form(...),
    status: str = Form(...),
    payment: str = Form(...),
    db: Session = Depends(get_db),
    user=Depends(get_current_user)
):
    booking = Booking(client=client, package=package, status=status, payment=payment)
    db.add(booking)
    db.commit()
    return RedirectResponse("/bookings", status_code=303)

@router.get("/edit/{bid}", response_class=HTMLResponse)
async def edit_booking(request: Request, bid: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    booking = db.query(Booking).filter(Booking.id == bid).first()
    if not booking:
        raise HTTPException(status_code=404, detail="Booking not found")
    packages = ["Serengeti Safari", "Kilimanjaro Trek"]
    return templates.TemplateResponse("bookings_edit.html", {"request": request, "booking": booking, "packages": packages, "user": user})

@router.post("/edit/{bid}", response_class=RedirectResponse)
async def update_booking(
    bid: int,
    client: str = Form(...),
    package: str = Form(...),
    status: str = Form(...),
    payment: str = Form(...),
    db: Session = Depends(get_db),
    user=Depends(get_current_user)
):
    booking = db.query(Booking).filter(Booking.id == bid).first()
    if not booking:
        raise HTTPException(status_code=404, detail="Booking not found")
    booking.client = client
    booking.package = package
    booking.status = status
    booking.payment = payment
    db.commit()
    return RedirectResponse("/bookings", status_code=303)

@router.get("/delete/{bid}", response_class=RedirectResponse)
async def delete_booking(bid: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    booking = db.query(Booking).filter(Booking.id == bid).first()
    if booking:
        db.delete(booking)
        db.commit()
    return RedirectResponse("/bookings", status_code=303)