from fastapi import APIRouter, Request, Form, UploadFile, File
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")

# Demo in-memory data
tours = [
    {"id": 1, "title": "Serengeti Safari", "description": "Wildlife adventure.", "pricing": 1200, "status": "Published"},
    {"id": 2, "title": "Kilimanjaro Trek", "description": "Mountain climbing.", "pricing": 950, "status": "Draft"},
]

@router.get("/", response_class=HTMLResponse)
async def tour_list(request: Request):
    return templates.TemplateResponse("tours.html", {"request": request, "tours": tours})

@router.get("/new", response_class=HTMLResponse)
async def create_tour_form(request: Request):
    return templates.TemplateResponse("tours_create.html", {"request": request})

@router.post("/new", response_class=HTMLResponse)
async def create_tour(
    request: Request,
    title: str = Form(...),
    description: str = Form(...),
    pricing: float = Form(...),
    media: UploadFile = File(None)
):
    # Add logic to save to DB; for demo, append to list
    tour = {"id": len(tours)+1, "title": title, "description": description, "pricing": pricing, "status": "Draft"}
    tours.append(tour)
    return templates.TemplateResponse("tours.html", {"request": request, "tours": tours})