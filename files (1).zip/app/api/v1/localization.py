from fastapi import APIRouter, Request, Form, Depends, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from app.models import LocalizationSetting
from app.deps import get_db
from app.auth import get_current_user

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")

@router.get("/", response_class=HTMLResponse)
async def localization_list(request: Request, db: Session = Depends(get_db), user=Depends(get_current_user)):
    settings = db.query(LocalizationSetting).all()
    return templates.TemplateResponse("localization.html", {"request": request, "settings": settings, "user": user})

@router.get("/new", response_class=HTMLResponse)
async def create_setting_form(request: Request, user=Depends(get_current_user)):
    return templates.TemplateResponse("localization_create.html", {"request": request, "user": user})

@router.post("/new", response_class=RedirectResponse)
async def create_setting(
    language: str = Form(...),
    currency: str = Form(...),
    region: str = Form(...),
    tax_rate: str = Form(...),
    is_active: bool = Form(...),
    db: Session = Depends(get_db),
    user=Depends(get_current_user)
):
    s = LocalizationSetting(language=language, currency=currency, region=region, tax_rate=tax_rate, is_active=is_active)
    db.add(s)
    db.commit()
    return RedirectResponse("/localization", status_code=303)

@router.get("/edit/{sid}", response_class=HTMLResponse)
async def edit_setting(request: Request, sid: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    s = db.query(LocalizationSetting).filter(LocalizationSetting.id == sid).first()
    if not s:
        raise HTTPException(status_code=404, detail="Setting not found")
    return templates.TemplateResponse("localization_edit.html", {"request": request, "setting": s, "user": user})

@router.post("/edit/{sid}", response_class=RedirectResponse)
async def update_setting(
    sid: int,
    language: str = Form(...),
    currency: str = Form(...),
    region: str = Form(...),
    tax_rate: str = Form(...),
    is_active: bool = Form(...),
    db: Session = Depends(get_db),
    user=Depends(get_current_user)
):
    s = db.query(LocalizationSetting).filter(LocalizationSetting.id == sid).first()
    if not s:
        raise HTTPException(status_code=404, detail="Setting not found")
    s.language = language
    s.currency = currency
    s.region = region
    s.tax_rate = tax_rate
    s.is_active = is_active
    db.commit()
    return RedirectResponse("/localization", status_code=303)

@router.get("/delete/{sid}", response_class=RedirectResponse)
async def delete_setting(sid: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    s = db.query(LocalizationSetting).filter(LocalizationSetting.id == sid).first()
    if s:
        db.delete(s)
        db.commit()
    return RedirectResponse("/localization", status_code=303)