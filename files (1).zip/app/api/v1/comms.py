from fastapi import APIRouter, Request, Form, Depends, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from app.models import Message
from app.deps import get_db
from app.auth import get_current_user

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")

@router.get("/", response_class=HTMLResponse)
async def comms_list(request: Request, db: Session = Depends(get_db), user=Depends(get_current_user)):
    messages = db.query(Message).order_by(Message.timestamp.desc()).all()
    return templates.TemplateResponse("comms.html", {"request": request, "messages": messages, "user": user})

@router.get("/new", response_class=HTMLResponse)
async def create_message_form(request: Request, user=Depends(get_current_user)):
    return templates.TemplateResponse("comms_create.html", {"request": request, "user": user})

@router.post("/new", response_class=RedirectResponse)
async def create_message(
    sender: str = Form(...),
    receiver: str = Form(...),
    content: str = Form(...),
    status: str = Form(...),
    db: Session = Depends(get_db),
    user=Depends(get_current_user)
):
    m = Message(sender=sender, receiver=receiver, content=content, status=status)
    db.add(m)
    db.commit()
    return RedirectResponse("/comms", status_code=303)

@router.get("/edit/{mid}", response_class=HTMLResponse)
async def edit_message(request: Request, mid: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    m = db.query(Message).filter(Message.id == mid).first()
    if not m:
        raise HTTPException(status_code=404, detail="Message not found")
    return templates.TemplateResponse("comms_edit.html", {"request": request, "m": m, "user": user})

@router.post("/edit/{mid}", response_class=RedirectResponse)
async def update_message(
    mid: int,
    sender: str = Form(...),
    receiver: str = Form(...),
    content: str = Form(...),
    status: str = Form(...),
    db: Session = Depends(get_db),
    user=Depends(get_current_user)
):
    m = db.query(Message).filter(Message.id == mid).first()
    if not m:
        raise HTTPException(status_code=404, detail="Message not found")
    m.sender = sender
    m.receiver = receiver
    m.content = content
    m.status = status
    db.commit()
    return RedirectResponse("/comms", status_code=303)

@router.get("/delete/{mid}", response_class=RedirectResponse)
async def delete_message(mid: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    m = db.query(Message).filter(Message.id == mid).first()
    if m:
        db.delete(m)
        db.commit()
    return RedirectResponse("/comms", status_code=303)