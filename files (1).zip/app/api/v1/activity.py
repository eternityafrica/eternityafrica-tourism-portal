from app.utils.google_calendar import create_google_event
from app.models import OAuthToken

@router.post("/new")
async def create_activity(
    # ...fields...
    db: Session = Depends(get_db),
    user = Depends(get_current_user)
):
    # ...Create activity in your DB...
    # Fetch user's Google OAuth token
    google_token = db.query(OAuthToken).filter_by(user_id=user.id, provider="google").order_by(OAuthToken.id.desc()).first()
    if google_token:
        event_data = {
            "summary": f"Safari Activity: {name}",
            "location": location,
            "description": description,
            "start": scheduled_date,  # ISO format
            "end": scheduled_date,    # adjust for duration
            "timezone": "Africa/Nairobi",
            "attendees": [user.email, assigned_guide_email]
        }
        create_google_event(google_token, event_data)
    return RedirectResponse("/activity", status_code=303)