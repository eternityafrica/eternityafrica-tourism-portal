@router.get("/", response_class=HTMLResponse)
async def affiliate_dashboard(request: Request, db: Session = Depends(get_db), user=Depends(get_current_user)):
    affiliates = db.query(Affiliate).all()
    recent_referrals = db.query(Referral).order_by(Referral.created_at.desc()).limit(10).all()
    stats = {
        "total_affiliates": db.query(Affiliate).count(),
        "total_referrals": db.query(Referral).count(),
        "pending": db.query(Referral).filter_by(status="Pending").count(),
        "confirmed_referrals": db.query(Referral).filter_by(status="Confirmed").count(),
        "paid_referrals": db.query(Referral).filter_by(status="Paid").count(),
    }
    return request.app.templates.TemplateResponse("affiliate_dashboard.html", {
        "request": request,
        "affiliates": affiliates,
        "recent_referrals": recent_referrals,
        "stats": stats,
        "user": user
    })