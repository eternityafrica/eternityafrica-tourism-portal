from fastapi import APIRouter, Request, Form, Depends, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from app.models import Campaign
from app.deps import get_db
from app.auth import get_current_user

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")

@router.get("/", response_class=HTMLResponse)
async def marketing_list(request: Request, db: Session = Depends(get_db), user=Depends(get_current_user)):
    campaigns = db.query(Campaign).all()
    return templates.TemplateResponse("marketing.html", {"request": request, "campaigns": campaigns, "user": user})

@router.get("/new", response_class=HTMLResponse)
async def create_campaign_form(request: Request, user=Depends(get_current_user)):
    return templates.TemplateResponse("marketing_create.html", {"request": request, "user": user})

@router.post("/new", response_class=RedirectResponse)
async def create_campaign(
    request: Request,
    name: str = Form(...),
    channel: str = Form(...),
    status: str = Form(...),
    reach: int = Form(...),
    leads: int = Form(...),
    db: Session = Depends(get_db),
    user=Depends(get_current_user)
):
    campaign = Campaign(name=name, channel=channel, status=status, reach=reach, leads=leads)
    db.add(campaign)
    db.commit()
    return RedirectResponse("/marketing", status_code=303)

@router.get("/edit/{cid}", response_class=HTMLResponse)
async def edit_campaign(request: Request, cid: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    campaign = db.query(Campaign).filter(Campaign.id == cid).first()
    if not campaign:
        raise HTTPException(status_code=404, detail="Campaign not found")
    return templates.TemplateResponse("marketing_edit.html", {"request": request, "campaign": campaign, "user": user})

@router.post("/edit/{cid}", response_class=RedirectResponse)
async def update_campaign(
    cid: int,
    name: str = Form(...),
    channel: str = Form(...),
    status: str = Form(...),
    reach: int = Form(...),
    leads: int = Form(...),
    db: Session = Depends(get_db),
    user=Depends(get_current_user)
):
    campaign = db.query(Campaign).filter(Campaign.id == cid).first()
    if not campaign:
        raise HTTPException(status_code=404, detail="Campaign not found")
    campaign.name = name
    campaign.channel = channel
    campaign.status = status
    campaign.reach = reach
    campaign.leads = leads
    db.commit()
    return RedirectResponse("/marketing", status_code=303)

@router.get("/delete/{cid}", response_class=RedirectResponse)
async def delete_campaign(cid: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    campaign = db.query(Campaign).filter(Campaign.id == cid).first()
    if campaign:
        db.delete(campaign)
        db.commit()
    return RedirectResponse("/marketing", status_code=303)

@router.get("/data")
async def reporting_data(db: Session = Depends(get_db)):
    campaigns = db.query(Campaign).all()
    return {
        "labels": [c.name for c in campaigns],
        "datasets": [{"label": "Reach", "data": [c.reach for c in campaigns]}]
    }