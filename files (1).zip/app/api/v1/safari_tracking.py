from fastapi import APIRouter, Request, Form, Depends, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from app.models import SafariTrack
from app.deps import get_db
from app.auth import get_current_user

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")

@router.get("/", response_class=HTMLResponse)
async def tracking_list(request: Request, db: Session = Depends(get_db), user=Depends(get_current_user)):
    tracks = db.query(SafariTrack).all()
    return templates.TemplateResponse("safari_tracking.html", {"request": request, "tracks": tracks, "user": user})

@router.get("/new", response_class=HTMLResponse)
async def create_track_form(request: Request, user=Depends(get_current_user)):
    return templates.TemplateResponse("safari_tracking_create.html", {"request": request, "user": user})

@router.post("/new", response_class=RedirectResponse)
async def create_track(
    client_name: str = Form(...),
    guide_name: str = Form(...),
    location: str = Form(...),
    status: str = Form(...),
    db: Session = Depends(get_db),
    user=Depends(get_current_user)
):
    t = SafariTrack(client_name=client_name, guide_name=guide_name, location=location, status=status)
    db.add(t)
    db.commit()
    return RedirectResponse("/safari_tracking", status_code=303)

@router.get("/edit/{tid}", response_class=HTMLResponse)
async def edit_track(request: Request, tid: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    t = db.query(SafariTrack).filter(SafariTrack.id == tid).first()
    if not t:
        raise HTTPException(status_code=404, detail="Track not found")
    return templates.TemplateResponse("safari_tracking_edit.html", {"request": request, "track": t, "user": user})

@router.post("/edit/{tid}", response_class=RedirectResponse)
async def update_track(
    tid: int,
    client_name: str = Form(...),
    guide_name: str = Form(...),
    location: str = Form(...),
    status: str = Form(...),
    db: Session = Depends(get_db),
    user=Depends(get_current_user)
):
    t = db.query(SafariTrack).filter(SafariTrack.id == tid).first()
    if not t:
        raise HTTPException(status_code=404, detail="Track not found")
    t.client_name = client_name
    t.guide_name = guide_name
    t.location = location
    t.status = status
    db.commit()
    return RedirectResponse("/safari_tracking", status_code=303)

@router.get("/delete/{tid}", response_class=RedirectResponse)
async def delete_track(tid: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    t = db.query(SafariTrack).filter(SafariTrack.id == tid).first()
    if t:
        db.delete(t)
        db.commit()
    return RedirectResponse("/safari_tracking", status_code=303)