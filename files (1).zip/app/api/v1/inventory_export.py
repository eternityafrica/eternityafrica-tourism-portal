from fastapi import APIRouter, Depends
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session
from app.models import InventoryItem
from app.deps import get_db
import io
import csv

router = APIRouter()

@router.get("/export", response_class=StreamingResponse)
async def export_inventory_csv(db: Session = Depends(get_db)):
    items = db.query(InventoryItem).all()
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow([
        "Name", "Category", "Description", "Quantity", "Unit", "Location", "Reorder Point", "Barcode", "QR Code"
    ])
    for item in items:
        writer.writerow([
            item.name, item.category, item.description, item.quantity, item.unit, item.location,
            item.reorder_point, item.barcode or "", item.qr_code or ""
        ])
    output.seek(0)
    headers = {"Content-Disposition": "attachment; filename=inventory.csv"}
    return StreamingResponse(output, media_type="text/csv", headers=headers)