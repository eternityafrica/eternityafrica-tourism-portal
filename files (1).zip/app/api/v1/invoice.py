from fastapi import APIRouter, Request, Form, Depends
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy.orm import Session
from app.models import Invoice, SalesOrder
from app.deps import get_db
import datetime

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")

@router.get("/", response_class=HTMLResponse)
async def invoice_list(request: Request, db: Session = Depends(get_db)):
    invoices = db.query(Invoice).order_by(Invoice.invoice_date.desc()).all()
    return templates.TemplateResponse("invoice.html", {"request": request, "invoices": invoices})

@router.get("/new", response_class=HTMLResponse)
async def invoice_create_form(request: Request, db: Session = Depends(get_db)):
    sales_orders = db.query(SalesOrder).all()
    return templates.TemplateResponse("invoice_create.html", {"request": request, "sales_orders": sales_orders})

@router.post("/new", response_class=RedirectResponse)
async def invoice_create(
    sales_order_id: int = Form(...),
    invoice_date: str = Form(...),
    due_date: str = Form(...),
    status: str = Form(...),
    amount_due: float = Form(...),
    db: Session = Depends(get_db)
):
    invoice = Invoice(
        sales_order_id=sales_order_id,
        invoice_date=datetime.datetime.fromisoformat(invoice_date),
        due_date=datetime.datetime.fromisoformat(due_date),
        status=status,
        amount_due=amount_due
    )
    db.add(invoice)
    db.commit()
    return RedirectResponse("/invoice", status_code=303)