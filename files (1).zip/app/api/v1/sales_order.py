from fastapi import APIRouter, Request, Form, Depends
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy.orm import Session
from app.models import SalesOrder, SalesOrderItem, InventoryItem
from app.deps import get_db
import datetime

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")

@router.get("/", response_class=HTMLResponse)
async def so_list(request: Request, db: Session = Depends(get_db)):
    orders = db.query(SalesOrder).order_by(SalesOrder.order_date.desc()).all()
    return templates.TemplateResponse("sales_order.html", {"request": request, "orders": orders})

@router.get("/new", response_class=HTMLResponse)
async def so_create_form(request: Request, db: Session = Depends(get_db)):
    items = db.query(InventoryItem).all()
    return templates.TemplateResponse("sales_order_create.html", {"request": request, "items": items})

@router.post("/new", response_class=RedirectResponse)
async def so_create(
    customer_name: str = Form(...),
    customer_contact: str = Form(...),
    order_date: str = Form(...),
    status: str = Form(...),
    total_amount: float = Form(...),
    notes: str = Form(...),
    db: Session = Depends(get_db)
):
    so = SalesOrder(
        customer_name=customer_name,
        customer_contact=customer_contact,
        order_date=datetime.datetime.fromisoformat(order_date),
        status=status,
        total_amount=total_amount,
        notes=notes
    )
    db.add(so)
    db.commit()
    return RedirectResponse("/sales_order", status_code=303)