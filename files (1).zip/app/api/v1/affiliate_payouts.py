from app.utils.email_notify import send_affiliate_email

def notify_affiliate_payout(payout, affiliate):
    subject = f"Payout Status Update for {affiliate.name}"
    content = f"""
        <p>Dear {affiliate.name},</p>
        <p>Your payout of ${payout.amount} for period {payout.period_start.strftime('%Y-%m-%d')} to {payout.period_end.strftime('%Y-%m-%d')} is now <strong>{payout.status}</strong>.</p>
        <p>Best regards,<br>Finance Team</p>
    """
    send_affiliate_email(affiliate.contact_email, subject, content)