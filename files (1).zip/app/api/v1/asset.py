from fastapi import APIRouter, Request, Form, Depends, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from app.models import Asset
from app.deps import get_db
from app.auth import get_current_user
import datetime

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")

@router.get("/", response_class=HTMLResponse)
async def asset_list(request: Request, db: Session = Depends(get_db), user=Depends(get_current_user)):
    assets = db.query(Asset).order_by(Asset.purchase_date.desc()).all()
    return templates.TemplateResponse("asset.html", {"request": request, "assets": assets, "user": user})

@router.get("/new", response_class=HTMLResponse)
async def asset_create_form(request: Request, user=Depends(get_current_user)):
    return templates.TemplateResponse("asset_create.html", {"request": request, "user": user})

@router.post("/new", response_class=RedirectResponse)
async def asset_create(
    name: str = Form(...),
    type: str = Form(...),
    description: str = Form(...),
    purchase_date: str = Form(...),
    purchase_value: float = Form(...),
    location: str = Form(...),
    assigned_to: str = Form(...),
    status: str = Form(...),
    depreciation_method: str = Form(...),
    useful_life_years: int = Form(...),
    db: Session = Depends(get_db),
    user=Depends(get_current_user)
):
    asset = Asset(
        name=name,
        type=type,
        description=description,
        purchase_date=datetime.datetime.fromisoformat(purchase_date),
        purchase_value=purchase_value,
        current_value=purchase_value, # initial value
        location=location,
        assigned_to=assigned_to,
        status=status,
        depreciation_method=depreciation_method,
        useful_life_years=useful_life_years
    )
    db.add(asset)
    db.commit()
    return RedirectResponse("/asset", status_code=303)

@router.get("/edit/{aid}", response_class=HTMLResponse)
async def asset_edit_form(request: Request, aid: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    asset = db.query(Asset).filter(Asset.id == aid).first()
    if not asset:
        raise HTTPException(status_code=404, detail="Asset not found")
    return templates.TemplateResponse("asset_edit.html", {"request": request, "asset": asset, "user": user})

@router.post("/edit/{aid}", response_class=RedirectResponse)
async def asset_update(
    aid: int,
    name: str = Form(...),
    type: str = Form(...),
    description: str = Form(...),
    purchase_date: str = Form(...),
    purchase_value: float = Form(...),
    location: str = Form(...),
    assigned_to: str = Form(...),
    status: str = Form(...),
    depreciation_method: str = Form(...),
    useful_life_years: int = Form(...),
    db: Session = Depends(get_db),
    user=Depends(get_current_user)
):
    asset = db.query(Asset).filter(Asset.id == aid).first()
    if not asset:
        raise HTTPException(status_code=404, detail="Asset not found")
    asset.name = name
    asset.type = type
    asset.description = description
    asset.purchase_date = datetime.datetime.fromisoformat(purchase_date)
    asset.purchase_value = purchase_value
    asset.location = location
    asset.assigned_to = assigned_to
    asset.status = status
    asset.depreciation_method = depreciation_method
    asset.useful_life_years = useful_life_years
    db.commit()
    return RedirectResponse("/asset", status_code=303)

@router.get("/delete/{aid}", response_class=RedirectResponse)
async def asset_delete(aid: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    asset = db.query(Asset).filter(Asset.id == aid).first()
    if asset:
        db.delete(asset)
        db.commit()
    return RedirectResponse("/asset", status_code=303)