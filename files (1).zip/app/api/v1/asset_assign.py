from fastapi import APIRouter, Form, Depends, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy.orm import Session
from app.models import Asset
from app.deps import get_db

router = APIRouter()

@router.get("/assign/{aid}", response_class=HTMLResponse)
async def assign_form(request: Request, aid: int, db: Session = Depends(get_db)):
    asset = db.query(Asset).filter(Asset.id == aid).first()
    return request.app.templates.TemplateResponse("asset_assign.html", {"request": request, "asset": asset})

@router.post("/assign/{aid}", response_class=RedirectResponse)
async def assign_asset(
    aid: int,
    assigned_to: str = Form(...),
    location: str = Form(...),
    db: Session = Depends(get_db)
):
    asset = db.query(Asset).filter(Asset.id == aid).first()
    asset.assigned_to = assigned_to
    asset.location = location
    asset.status = "In Use"
    db.commit()
    return RedirectResponse("/asset", status_code=303)