from fastapi import APIRouter, Request, Form, Depends, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from app.models import Affiliate, Referral
from app.deps import get_db
from app.auth import get_current_user

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")

# Affiliates
@router.get("/affiliates", response_class=HTMLResponse)
async def affiliate_list(request: Request, db: Session = Depends(get_db), user=Depends(get_current_user)):
    affiliates = db.query(Affiliate).all()
    return templates.TemplateResponse("affiliates.html", {"request": request, "affiliates": affiliates, "user": user})

@router.get("/affiliates/new", response_class=HTMLResponse)
async def affiliate_create_form(request: Request, user=Depends(get_current_user)):
    return templates.TemplateResponse("affiliate_create.html", {"request": request, "user": user})

@router.post("/affiliates/new", response_class=RedirectResponse)
async def affiliate_create(
    name: str = Form(...),
    contact_email: str = Form(...),
    referral_code: str = Form(...),
    website: str = Form(...),
    notes: str = Form(...),
    db: Session = Depends(get_db),
    user=Depends(get_current_user)
):
    a = Affiliate(name=name, contact_email=contact_email, referral_code=referral_code, website=website, notes=notes)
    db.add(a)
    db.commit()
    return RedirectResponse("/affiliate/affiliates", status_code=303)

@router.get("/affiliates/edit/{aid}", response_class=HTMLResponse)
async def affiliate_edit_form(request: Request, aid: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    a = db.query(Affiliate).filter(Affiliate.id == aid).first()
    if not a:
        raise HTTPException(status_code=404, detail="Affiliate not found")
    return templates.TemplateResponse("affiliate_edit.html", {"request": request, "affiliate": a, "user": user})

@router.post("/affiliates/edit/{aid}", response_class=RedirectResponse)
async def affiliate_update(
    aid: int,
    name: str = Form(...),
    contact_email: str = Form(...),
    referral_code: str = Form(...),
    website: str = Form(...),
    notes: str = Form(...),
    db: Session = Depends(get_db),
    user=Depends(get_current_user)
):
    a = db.query(Affiliate).filter(Affiliate.id == aid).first()
    if not a:
        raise HTTPException(status_code=404, detail="Affiliate not found")
    a.name = name
    a.contact_email = contact_email
    a.referral_code = referral_code
    a.website = website
    a.notes = notes
    db.commit()
    return RedirectResponse("/affiliate/affiliates", status_code=303)

@router.get("/affiliates/delete/{aid}", response_class=RedirectResponse)
async def affiliate_delete(aid: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    a = db.query(Affiliate).filter(Affiliate.id == aid).first()
    if a:
        db.delete(a)
        db.commit()
    return RedirectResponse("/affiliate/affiliates", status_code=303)

# Referrals
@router.get("/referrals", response_class=HTMLResponse)
async def referral_list(request: Request, db: Session = Depends(get_db), user=Depends(get_current_user)):
    referrals = db.query(Referral).all()
    return templates.TemplateResponse("referrals.html", {"request": request, "referrals": referrals, "user": user})

@router.get("/referrals/new", response_class=HTMLResponse)
async def referral_create_form(request: Request, db: Session = Depends(get_db), user=Depends(get_current_user)):
    affiliates = db.query(Affiliate).all()
    return templates.TemplateResponse("referral_create.html", {"request": request, "affiliates": affiliates, "user": user})

@router.post("/referrals/new", response_class=RedirectResponse)
async def referral_create(
    affiliate_id: int = Form(...),
    client_name: str = Form(...),
    client_email: str = Form(...),
    booking_id: int = Form(None),
    status: str = Form(...),
    db: Session = Depends(get_db),
    user=Depends(get_current_user)
):
    r = Referral(affiliate_id=affiliate_id, client_name=client_name, client_email=client_email, booking_id=booking_id, status=status)
    db.add(r)
    db.commit()
    return RedirectResponse("/affiliate/referrals", status_code=303)

@router.get("/referrals/edit/{rid}", response_class=HTMLResponse)
async def referral_edit_form(request: Request, rid: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    r = db.query(Referral).filter(Referral.id == rid).first()
    affiliates = db.query(Affiliate).all()
    if not r:
        raise HTTPException(status_code=404, detail="Referral not found")
    return templates.TemplateResponse("referral_edit.html", {"request": request, "referral": r, "affiliates": affiliates, "user": user})

@router.post("/referrals/edit/{rid}", response_class=RedirectResponse)
async def referral_update(
    rid: int,
    affiliate_id: int = Form(...),
    client_name: str = Form(...),
    client_email: str = Form(...),
    booking_id: int = Form(None),
    status: str = Form(...),
    db: Session = Depends(get_db),
    user=Depends(get_current_user)
):
    r = db.query(Referral).filter(Referral.id == rid).first()
    if not r:
        raise HTTPException(status_code=404, detail="Referral not found")
    r.affiliate_id = affiliate_id
    r.client_name = client_name
    r.client_email = client_email
    r.booking_id = booking_id
    r.status = status
    db.commit()
    return RedirectResponse("/affiliate/referrals", status_code=303)

@router.get("/referrals/delete/{rid}", response_class=RedirectResponse)
async def referral_delete(rid: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    r = db.query(Referral).filter(Referral.id == rid).first()
    if r:
        db.delete(r)
        db.commit()
    return RedirectResponse("/affiliate/referrals", status_code=303)