from fastapi import APIRouter, Request, Form, Depends
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from app.models import Notification
from app.deps import get_db
from app.auth import get_current_user

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")

@router.get("/", response_class=HTMLResponse)
async def notification_list(request: Request, db: Session = Depends(get_db), user=Depends(get_current_user)):
    notes = db.query(Notification).filter_by(recipient=user.email).order_by(Notification.created_at.desc()).all()
    return templates.TemplateResponse("notifications.html", {"request": request, "notes": notes, "user": user})

@router.get("/mark_read/{nid}", response_class=RedirectResponse)
async def mark_as_read(nid: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    note = db.query(Notification).filter(Notification.id == nid).first()
    if note:
        note.read = True
        db.commit()
    return RedirectResponse("/notifications", status_code=303)