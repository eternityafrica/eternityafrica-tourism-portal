from fastapi import APIRouter, Request, Depends
from sqlalchemy.orm import Session
from app.models import InventoryItem
from app.deps import get_db

router = APIRouter()

@router.get("/analytics", response_class=HTMLResponse)
async def inventory_analytics(request: Request, db: Session = Depends(get_db)):
    items = db.query(InventoryItem).all()
    stats = {
        "total_items": len(items),
        "total_quantity": sum(i.quantity for i in items),
        "low_stock": sum(1 for i in items if i.quantity <= i.reorder_point),
        "categories": list(set(i.category for i in items)),
    }
    # Optional: Compute per-category stats
    category_stats = {}
    for cat in stats["categories"]:
        cat_items = [i for i in items if i.category == cat]
        category_stats[cat] = {
            "count": len(cat_items),
            "total_quantity": sum(i.quantity for i in cat_items),
            "low_stock": sum(1 for i in cat_items if i.quantity <= i.reorder_point),
        }
    return request.app.templates.TemplateResponse("inventory_analytics.html", {
        "request": request,
        "stats": stats,
        "category_stats": category_stats,
        "items": items,
    })