from fastapi import APIRouter, Request, Form, Depends, Cookie
from fastapi.responses import HTMLResponse, RedirectResponse
from app.models import PayoutDispute, Payout, Affiliate
from app.deps import get_db

router = APIRouter()

@router.get("/disputes/new/{payout_id}", response_class=HTMLResponse)
async def dispute_form(request: Request, payout_id: int, db=Depends(get_db), affiliate_id: str = Cookie(None)):
    payout = db.query(Payout).filter_by(id=payout_id).first()
    return request.app.templates.TemplateResponse("payout_dispute_create.html", {"request": request, "payout": payout})

@router.post("/disputes/new/{payout_id}")
async def create_dispute(
    payout_id: int,
    reason: str = Form(...),
    db=Depends(get_db),
    affiliate_id: str = Cookie(None)
):
    dispute = PayoutDispute(
        payout_id=payout_id,
        affiliate_id=affiliate_id,
        reason=reason,
        status="Open"
    )
    db.add(dispute)
    db.commit()
    return RedirectResponse("/affiliate/self_dashboard", status_code=303)

@router.get("/disputes", response_class=HTMLResponse)
async def list_disputes(request: Request, db=Depends(get_db), affiliate_id: str = Cookie(None)):
    disputes = db.query(PayoutDispute).filter_by(affiliate_id=affiliate_id).order_by(PayoutDispute.created_at.desc()).all()
    return request.app.templates.TemplateResponse("payout_disputes.html", {"request": request, "disputes": disputes})