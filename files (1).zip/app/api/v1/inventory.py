from fastapi import APIRouter, Request, Form, Depends, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from app.models import InventoryItem, InventoryMovement
from app.deps import get_db
from app.auth import get_current_user
import datetime

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")

@router.get("/", response_class=HTMLResponse)
async def inventory_list(request: Request, db: Session = Depends(get_db), user=Depends(get_current_user)):
    items = db.query(InventoryItem).order_by(InventoryItem.name.asc()).all()
    return templates.TemplateResponse("inventory.html", {"request": request, "items": items, "user": user})

@router.get("/new", response_class=HTMLResponse)
async def inventory_create_form(request: Request, user=Depends(get_current_user)):
    return templates.TemplateResponse("inventory_create.html", {"request": request, "user": user})

@router.post("/new", response_class=RedirectResponse)
async def inventory_create(
    name: str = Form(...),
    category: str = Form(...),
    description: str = Form(...),
    quantity: int = Form(...),
    unit: str = Form(...),
    location: str = Form(...),
    reorder_point: int = Form(...),
    db: Session = Depends(get_db),
    user=Depends(get_current_user)
):
    item = InventoryItem(
        name=name,
        category=category,
        description=description,
        quantity=quantity,
        unit=unit,
        location=location,
        reorder_point=reorder_point
    )
    db.add(item)
    db.commit()
    return RedirectResponse("/inventory", status_code=303)

@router.get("/edit/{iid}", response_class=HTMLResponse)
async def inventory_edit_form(request: Request, iid: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    item = db.query(InventoryItem).filter(InventoryItem.id == iid).first()
    if not item:
        raise HTTPException(status_code=404, detail="Inventory item not found")
    return templates.TemplateResponse("inventory_edit.html", {"request": request, "item": item, "user": user})

@router.post("/edit/{iid}", response_class=RedirectResponse)
async def inventory_update(
    iid: int,
    name: str = Form(...),
    category: str = Form(...),
    description: str = Form(...),
    quantity: int = Form(...),
    unit: str = Form(...),
    location: str = Form(...),
    reorder_point: int = Form(...),
    db: Session = Depends(get_db),
    user=Depends(get_current_user)
):
    item = db.query(InventoryItem).filter(InventoryItem.id == iid).first()
    if not item:
        raise HTTPException(status_code=404, detail="Inventory item not found")
    item.name = name
    item.category = category
    item.description = description
    item.quantity = quantity
    item.unit = unit
    item.location = location
    item.reorder_point = reorder_point
    db.commit()
    return RedirectResponse("/inventory", status_code=303)

@router.get("/delete/{iid}", response_class=RedirectResponse)
async def inventory_delete(iid: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    item = db.query(InventoryItem).filter(InventoryItem.id == iid).first()
    if item:
        db.delete(item)
        db.commit()
    return RedirectResponse("/inventory", status_code=303)

@router.get("/movement/{iid}", response_class=HTMLResponse)
async def movement_form(request: Request, iid: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    item = db.query(InventoryItem).filter(InventoryItem.id == iid).first()
    return templates.TemplateResponse("inventory_movement.html", {"request": request, "item": item, "user": user})

@router.post("/movement/{iid}", response_class=RedirectResponse)
async def movement_add(
    iid: int,
    movement_type: str = Form(...),
    quantity: int = Form(...),
    notes: str = Form(...),
    db: Session = Depends(get_db),
    user=Depends(get_current_user)
):
    item = db.query(InventoryItem).filter(InventoryItem.id == iid).first()
    if not item:
        raise HTTPException(status_code=404, detail="Inventory item not found")
    # Adjust quantity based on movement type
    if movement_type == "In":
        item.quantity += quantity
    elif movement_type == "Out":
        item.quantity -= quantity
    elif movement_type == "Adjustment":
        item.quantity = quantity
    movement = InventoryMovement(
        item_id=iid,
        movement_type=movement_type,
        quantity=quantity,
        notes=notes
    )
    db.add(movement)
    db.commit()
    return RedirectResponse("/inventory", status_code=303)