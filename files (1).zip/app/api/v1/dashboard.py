from fastapi import APIRouter, Request, Depends
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from app.deps import get_current_user
import datetime

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")

def get_role_widgets(role):
    widgets = [
        {"title": "Upcoming Tours", "value": 5, "icon": "🗺️", "link": "/tours"},
        {"title": "Pending Bookings", "value": 12, "icon": "📑", "link": "/bookings"},
        {"title": "Client Messages", "value": 3, "icon": "💬", "link": "/comms"},
    ]
    if role == "Finance":
        widgets.extend([
            {"title": "Revenue This Month", "value": "$45,000", "icon": "💰", "link": "/finance"},
            {"title": "Expenses Pending", "value": "$5,000", "icon": "🧾", "link": "/finance"},
        ])
    if role == "HR":
        widgets.extend([
            {"title": "Leave Requests", "value": 2, "icon": "🌴", "link": "/hr"},
            {"title": "Performance Reviews", "value": 7, "icon": "📈", "link": "/hr"},
        ])
    if role == "Admin":
        widgets.append({"title": "System Health", "value": "All OK", "icon": "✅", "link": "/admin"})
    return widgets

@router.get("/", response_class=HTMLResponse)
async def dashboard(request: Request, user=Depends(get_current_user)):
    role = user.get("role", "Admin")
    widgets = get_role_widgets(role)
    notifications = [
        {"message": "New booking received", "time": "2 min ago"},
        {"message": "Staff leave request pending", "time": "10 min ago"},
        {"message": "Invoice #1234 overdue", "time": "1 hr ago"},
    ]
    analytics = {
        "bookings": 120,
        "revenue": 45000,
        "satisfaction": 95,
        "conversion_rate": "12%",
        "avg_spend": "$375",
        "top_tours": ["Serengeti Explorer", "Kilimanjaro Trek", "Zanzibar Getaway"]
    }
    quick_links = [
        {"label": "Manage Tours", "href": "/tours"},
        {"label": "View Bookings", "href": "/bookings"},
        {"label": "Messages", "href": "/comms"},
        {"label": "Finance", "href": "/finance"},
        {"label": "Human Resources", "href": "/hr"},
        {"label": "Marketing", "href": "/marketing"},
    ]
    department_tabs = ["Operations", "Finance", "HR", "Marketing"]
    return templates.TemplateResponse("dashboard.html", {
        "request": request,
        "user": user,
        "widgets": widgets,
        "notifications": notifications,
        "analytics": analytics,
        "quick_links": quick_links,
        "department_tabs": department_tabs,
        "today": datetime.date.today()
    })