import httpx
from fastapi import APIRouter, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")

JOKE_API_URL = "https://official-joke-api.appspot.com/random_joke"

@router.get("/", response_class=HTMLResponse)
async def get_joke(request: Request):
    async with httpx.AsyncClient() as client:
        response = await client.get(JOKE_API_URL)
        joke = response.json() if response.status_code == 200 else {"setup": "No joke found!", "punchline": ""}
    return templates.TemplateResponse("joke.html", {"request": request, "joke": joke})