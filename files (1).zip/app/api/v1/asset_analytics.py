from fastapi import APIRouter, Request, Depends
from sqlalchemy.orm import Session
from app.models import Asset
from app.deps import get_db
from app.utils.depreciation import straight_line_depreciation, declining_balance_depreciation

router = APIRouter()

@router.get("/analytics", response_class=HTMLResponse)
async def asset_analytics(request: Request, db: Session = Depends(get_db)):
    assets = db.query(Asset).all()
    stats = {
        "total_assets": len(assets),
        "total_value": sum(a.purchase_value for a in assets),
        "total_current_value": sum(
            straight_line_depreciation(a.purchase_value, a.useful_life_years, a.purchase_date)
            if a.depreciation_method == "Straight-Line"
            else declining_balance_depreciation(a.purchase_value, a.useful_life_years, a.purchase_date)
            for a in assets
        ),
        "assigned": sum(1 for a in assets if a.status == "In Use"),
        "available": sum(1 for a in assets if a.status == "Available"),
        "maintenance": sum(1 for a in assets if a.status == "Maintenance"),
        "retired": sum(1 for a in assets if a.status == "Retired"),
    }
    return request.app.templates.TemplateResponse("asset_analytics.html", {"request": request, "stats": stats})