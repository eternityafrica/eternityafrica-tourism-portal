from fastapi import APIRouter, Request, Form, Depends, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from app.models import User
from app.deps import get_db
from app.auth import get_current_user

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")

@router.get("/", response_class=HTMLResponse)
async def rbac_list(request: Request, db: Session = Depends(get_db), user=Depends(get_current_user)):
    users = db.query(User).all()
    return templates.TemplateResponse("rbac.html", {"request": request, "users": users, "user": user})

@router.get("/new", response_class=HTMLResponse)
async def create_user_form(request: Request, user=Depends(get_current_user)):
    return templates.TemplateResponse("rbac_create.html", {"request": request, "user": user})

@router.post("/new", response_class=RedirectResponse)
async def create_user(
    email: str = Form(...),
    role: str = Form(...),
    is_active: bool = Form(...),
    db: Session = Depends(get_db),
    user=Depends(get_current_user)
):
    u = User(email=email, role=role, is_active=is_active)
    db.add(u)
    db.commit()
    return RedirectResponse("/rbac", status_code=303)

@router.get("/edit/{uid}", response_class=HTMLResponse)
async def edit_user(request: Request, uid: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    u = db.query(User).filter(User.id == uid).first()
    if not u:
        raise HTTPException(status_code=404, detail="User not found")
    return templates.TemplateResponse("rbac_edit.html", {"request": request, "u": u, "user": user})

@router.post("/edit/{uid}", response_class=RedirectResponse)
async def update_user(
    uid: int,
    email: str = Form(...),
    role: str = Form(...),
    is_active: bool = Form(...),
    db: Session = Depends(get_db),
    user=Depends(get_current_user)
):
    u = db.query(User).filter(User.id == uid).first()
    if not u:
        raise HTTPException(status_code=404, detail="User not found")
    u.email = email
    u.role = role
    u.is_active = is_active
    db.commit()
    return RedirectResponse("/rbac", status_code=303)

@router.get("/delete/{uid}", response_class=RedirectResponse)
async def delete_user(uid: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    u = db.query(User).filter(User.id == uid).first()
    if u:
        db.delete(u)
        db.commit()
    return RedirectResponse("/rbac", status_code=303)