from xero_python.accounting import AccountingApi, Contact, Address, Phone
from xero_python.api_client import ApiClient, Configuration

def create_xero_contact(affiliate, xero_access_token, xero_tenant_id):
    config = Configuration(debug=True)
    api_client = ApiClient(config)
    accounting_api = AccountingApi(api_client)
    contact = Contact(
        name=affiliate.name,
        email_address=affiliate.contact_email,
        bank_account_details=affiliate.bank_account_number,
        addresses=[Address(address_type="STREET", address_line1=affiliate.bank_name)],
        phones=[Phone(phone_type="DEFAULT", phone_number=affiliate.bank_account_number)]
    )
    response = accounting_api.create_contacts(
        xero_tenant_id,
        contacts=[contact],
        xero_access_token=xero_access_token
    )
    return response