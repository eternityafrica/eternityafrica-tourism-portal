from app.models import Staff, Activity, InventoryItem

def assign_guide(activity_date, db):
    available_guides = db.query(Staff).filter_by(is_active=True).all()
    for guide in available_guides:
        # Guide must not have another activity at this time
        conflict = db.query(Activity).filter(
            Activity.assigned_guide == guide.name,
            Activity.scheduled_date == activity_date
        ).count()
        if not conflict:
            return guide.name
    return None

def assign_vehicle(activity_date, db):
    vehicles = db.query(InventoryItem).filter_by(item_type="Vehicle", status="Available").all()
    for vehicle in vehicles:
        # Check vehicle not in use
        conflict = db.query(Activity).filter(
            Activity.location == vehicle.location,
            Activity.scheduled_date == activity_date
        ).count()
        if not conflict:
            return vehicle.name
    return None