def log_audit(db, user, action, target_type, target_id, details=""):
    from app.models import AuditTrail
    audit = AuditTrail(
        user=user,
        action=action,
        target_type=target_type,
        target_id=target_id,
        details=details
    )
    db.add(audit)
    db.commit()