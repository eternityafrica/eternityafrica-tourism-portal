from googleapiclient.discovery import build
from google.oauth2.credentials import Credentials

def create_google_event(user_tokens, event_data):
    creds = Credentials(
        token=user_tokens.access_token,
        refresh_token=user_tokens.refresh_token,
        client_id="your_client_id",
        client_secret="your_client_secret",
        token_uri="https://oauth2.googleapis.com/token"
    )
    service = build('calendar', 'v3', credentials=creds)
    event = {
        'summary': event_data['summary'],
        'location': event_data['location'],
        'description': event_data['description'],
        'start': {'dateTime': event_data['start'], 'timeZone': event_data['timezone']},
        'end': {'dateTime': event_data['end'], 'timeZone': event_data['timezone']},
        'attendees': [{'email': email} for email in event_data.get('attendees', [])]
    }
    created = service.events().insert(calendarId='primary', body=event).execute()
    return created['id']