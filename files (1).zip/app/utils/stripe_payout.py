import stripe
import os

stripe.api_key = os.getenv("STRIPE_SECRET_KEY")

def create_stripe_payout(amount, currency, destination_account, description):
    payout = stripe.Payout.create(
        amount=int(amount * 100),
        currency=currency,
        destination=destination_account,
        method="standard",
        statement_descriptor=description,
    )
    return payout