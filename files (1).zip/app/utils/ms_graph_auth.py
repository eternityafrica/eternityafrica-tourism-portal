from msal import ConfidentialClientApplication

def get_access_token(client_id, client_secret, tenant_id, redirect_uri, username, password):
    app = ConfidentialClientApplication(
        client_id,
        authority=f"https://login.microsoftonline.com/{tenant_id}",
        client_credential=client_secret,
    )
    result = app.acquire_token_by_username_password(
        username, password, scopes=["https://graph.microsoft.com/.default"]
    )
    return result.get("access_token")