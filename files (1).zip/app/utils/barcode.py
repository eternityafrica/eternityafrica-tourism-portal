import qrcode
import barcode
from barcode.writer import ImageWriter

def generate_barcode(data, filename):
    code128 = barcode.get('code128', data, writer=ImageWriter())
    code128.save(filename)  # saves PNG

def generate_qr(data, filename):
    img = qrcode.make(data)
    img.save(filename)