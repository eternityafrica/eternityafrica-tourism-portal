from quickbooks import QuickBooks
from quickbooks.objects.vendor import Vendor

def create_qb_vendor(affiliate, qb_client):
    vendor = Vendor()
    vendor.DisplayName = affiliate.name
    vendor.PrimaryEmailAddr = {"Address": affiliate.contact_email}
    vendor.AcctNum = affiliate.bank_account_number
    vendor.save(qb_client)
    return vendor