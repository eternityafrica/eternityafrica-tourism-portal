def send_reorder_email(item, admin_email):
    # Use SendGrid, SMTP, etc.
    pass