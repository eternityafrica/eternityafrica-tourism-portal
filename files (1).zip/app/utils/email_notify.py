def send_affiliate_email(to_email, subject, content, affiliate):
    if affiliate.notify_payouts or affiliate.notify_status:
        # send email as before...
        pass