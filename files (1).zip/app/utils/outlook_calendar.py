import requests

def create_outlook_event(access_token, user_email, event_data):
    endpoint = f"https://graph.microsoft.com/v1.0/users/{user_email}/events"
    headers = {
        "Authorization": f"Bearer {access_token}",
        "Content-Type": "application/json"
    }
    event = {
        "subject": event_data['subject'],
        "body": { "contentType": "HTML", "content": event_data['description'] },
        "start": { "dateTime": event_data['start'], "timeZone": event_data['timezone'] },
        "end": { "dateTime": event_data['end'], "timeZone": event_data['timezone'] },
        "location": { "displayName": event_data['location'] },
        "attendees": [
            {
                "emailAddress": { "address": email, "name": name },
                "type": "required"
            } for email, name in event_data.get('attendees', [])
        ]
    }
    resp = requests.post(endpoint, json=event, headers=headers)
    resp.raise_for_status()
    return resp.json()["id"]