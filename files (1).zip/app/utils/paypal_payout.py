import paypalrestsdk
import os

paypalrestsdk.configure({
  "mode": "live", # or "sandbox"
  "client_id": os.getenv("PAYPAL_CLIENT_ID"),
  "client_secret": os.getenv("PAYPAL_CLIENT_SECRET"),
})

def create_paypal_payout(recipient_email, amount, currency, note, sender_item_id):
    payout = paypalrestsdk.Payout({
        "sender_batch_header": {
            "sender_batch_id": sender_item_id,
            "email_subject": "You have a payout!",
        },
        "items": [{
            "recipient_type": "EMAIL",
            "amount": {
                "value": str(amount),
                "currency": currency
            },
            "receiver": recipient_email,
            "note": note,
            "sender_item_id": sender_item_id,
        }]
    })
    if payout.create(sync_mode=True):
        return payout
    else:
        raise Exception(f"PayPal Payout failed: {payout.error}")