import datetime

def straight_line_depreciation(purchase_value, useful_life_years, purchase_date, as_of_date=None):
    if as_of_date is None:
        as_of_date = datetime.datetime.utcnow()
    years_used = (as_of_date - purchase_date).days / 365.25
    years_used = min(years_used, useful_life_years)
    annual_depreciation = purchase_value / useful_life_years
    accumulated_depreciation = annual_depreciation * years_used
    current_value = max(0.0, purchase_value - accumulated_depreciation)
    return round(current_value, 2)

def declining_balance_depreciation(purchase_value, useful_life_years, purchase_date, as_of_date=None, rate=None):
    if as_of_date is None:
        as_of_date = datetime.datetime.utcnow()
    years_used = int((as_of_date - purchase_date).days / 365.25)
    if rate is None:
        rate = 2.0 / useful_life_years  # Double declining default
    value = purchase_value
    for year in range(years_used):
        value -= value * rate
    return round(max(0.0, value), 2)