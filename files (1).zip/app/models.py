class Invoice(Base):
    __tablename__ = "invoices"
    id = Column(Integer, primary_key=True)
    sales_order_id = Column(Integer)
    invoice_date = Column(DateTime, default=datetime.datetime.utcnow)
    due_date = Column(DateTime)
    status = Column(String)  # Draft, Sent, Paid, Overdue
    amount_due = Column(Float)
    amount_paid = Column(Float, default=0)